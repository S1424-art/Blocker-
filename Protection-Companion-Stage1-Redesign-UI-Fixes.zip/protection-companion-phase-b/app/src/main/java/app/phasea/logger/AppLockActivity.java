package app.phasea.logger;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;

/** The app-local PIN gate. It never modifies the Android device lock or Device Owner state. */
public final class AppLockActivity extends Activity {
    private EditText pinInput;
    private TextView message;
    private boolean verifying;

    @Override protected void onCreate(Bundle state) {
        Ui.prepareTheme(this);
        super.onCreate(state);
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE);
        Ui.applyWindowColors(this);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        LinearLayout content = Ui.column(this);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.addView(Ui.title(this, "Protection Companion"));
        content.addView(Ui.subtitle(this, "Enter your app PIN to continue."));
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "App locked", 19, true, R.color.pc_text));
        card.addView(Ui.text(this, "This PIN protects access to the app's settings and blocklist. It is separate from Android's uninstall-protection policy.",
                13, false, R.color.pc_muted));
        pinInput = new EditText(this);
        pinInput.setSingleLine(true);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        pinInput.setHint("6–12 digit PIN");
        pinInput.setTextSize(20);
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setSelectAllOnFocus(true);
        pinInput.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        card.addView(pinInput);
        message = Ui.text(this, "", 13, false, R.color.pc_muted);
        message.setPadding(0, Ui.dp(this, 6), 0, 0);
        card.addView(message);
        content.addView(card);
        setContentView(Ui.page(this, content));
        pinInput.requestFocus();
        pinInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (verifying || s == null) return;
                int expectedLength = AppLockManager.configuredPinLength(AppLockActivity.this);
                if (expectedLength >= 6 && expectedLength <= 12 && s.length() == expectedLength) {
                    pinInput.post(() -> tryUnlock());
                }
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        pinInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                // Compatibility path for PINs created by older builds before PIN length was stored.
                tryUnlock();
                return true;
            }
            return false;
        });
        updateLockoutMessage();
    }

    private void tryUnlock() {
        if (verifying) return;
        if (AppLockManager.remainingLockoutMs(this) > 0) {
            updateLockoutMessage();
            return;
        }
        String pin = pinInput.getText() == null ? "" : pinInput.getText().toString();
        if (pin.length() < 6 || pin.length() > 12) {
            pinInput.setError("Enter your 6–12 digit PIN");
            return;
        }
        verifying = true;
        AppLockManager.VerifyResult result = AppLockManager.verifyPin(this, pin);
        pinInput.setText("");
        verifying = false;
        if (result == AppLockManager.VerifyResult.SUCCESS) {
            AppLockManager.unlockSession(this);
            Intent home = new Intent(this, MainActivity.class);
            home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(home);
            finish();
        } else if (result == AppLockManager.VerifyResult.TEMPORARILY_LOCKED) {
            updateLockoutMessage();
        } else {
            message.setText(result == AppLockManager.VerifyResult.NOT_CONFIGURED
                    ? "The PIN is unavailable. Use phone screen-lock recovery if configured."
                    : "Incorrect PIN. After five failed attempts, entry pauses for 30 seconds.");
            message.setTextColor(Ui.color(this, R.color.pc_warn));
        }
    }

    private void updateLockoutMessage() {
        long remaining = AppLockManager.remainingLockoutMs(this);
        if (message == null) return;
        if (remaining > 0) {
            message.setText("Try again in " + Math.max(1L, (remaining + 999L) / 1000L) + " seconds.");
            message.setTextColor(Ui.color(this, R.color.pc_caution));
        } else {
            message.setText("");
        }
    }

    @Override public void onBackPressed() {
        // Stay on the lock screen; Home is still available through the Android system navigation.
    }
}
