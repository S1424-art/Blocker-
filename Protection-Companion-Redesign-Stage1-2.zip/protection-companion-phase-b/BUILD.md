# Build notes

- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- compileSdk 34
- minSdk 30; targetSdk 33

Run `gradle --no-daemon assembleDebug` from this project root. Expected output: `app/build/outputs/apk/debug/app-debug.apk`. The ZIP has not been compiled in this environment; use GitHub Actions to verify compilation and inspect the run's commit SHA.
