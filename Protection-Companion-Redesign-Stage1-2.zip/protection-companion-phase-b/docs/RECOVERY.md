# Recovery and safety notes — development build

This build does not provision Device Owner and does not apply device policy restrictions. Best-effort blocking is off by default.

If Accessibility redirection becomes disruptive, open Android Settings → Accessibility → Installed apps/services → Protection Companion and turn the service off. Alternatively, use the Settings screen in the app to disable best-effort blocking. Keep Android Settings and the launcher unblocked during testing.

No guarantee of uninstall prevention, force-stop prevention, or OS-level suspension is made. Device Owner work must be a separate reviewed stage with a device-specific recovery rehearsal before any policy is applied. Do not remove accounts or provision the primary phone as part of this build.
