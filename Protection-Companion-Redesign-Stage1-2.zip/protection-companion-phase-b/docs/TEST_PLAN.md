# Phone test plan — Stage 1/2

- [ ] CI run identifies the intended root project and source tree.
- [ ] APK installs and launches on Android 13 / Samsung A32 5G.
- [ ] App list shows names and icons; search filters results.
- [ ] Selected list survives force-closing and reopening the app.
- [ ] System / Light / Dark choices are visible and persist after relaunch.
- [ ] Blocking defaults to off after clean install.
- [ ] With Accessibility enabled and blocking on, selected app redirects Home (best effort); observe any brief flash.
- [ ] Unselected app still opens normally.
- [ ] Circuit breaker pauses after repeated redirects.
- [ ] Disable Accessibility to verify the UI accurately reports it is inactive.
- [ ] Settings, connectivity, uninstall protection, and Device Owner are not represented as enforced.

Do not test on essential apps or suspend system packages. Device Owner enforcement is out of scope for this build.
