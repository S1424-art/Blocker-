package app.phasea.logger;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Minimal home screen for the app-blocking product. Enforcement is explicitly best-effort. */
public class MainActivity extends Activity {
    private TextView status, count, accessibility, enforcement;
    private LinearLayout root;

    @Override protected void onCreate(Bundle state) {
        Ui.applyTheme(this);
        super.onCreate(state);
        root = Ui.column(this);
        root.setPadding(Ui.dp(this, 20), Ui.dp(this, 22), Ui.dp(this, 20), Ui.dp(this, 24));

        TextView eyebrow = Ui.text(this, "PERSONAL FOCUS", 12, true, R.color.pc_primary);
        eyebrow.setLetterSpacing(.12f);
        root.addView(eyebrow);
        TextView title = Ui.text(this, "Protection Companion", 27, true, R.color.pc_text);
        title.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 5));
        root.addView(title);
        TextView subtitle = Ui.text(this, "Choose the apps you want to keep out of reach.", 15, false, R.color.pc_muted);
        subtitle.setPadding(0, 0, 0, Ui.dp(this, 18));
        root.addView(subtitle);

        LinearLayout summary = Ui.card(this);
        TextView label = Ui.text(this, "PROTECTION STATUS", 11, true, R.color.pc_muted);
        label.setLetterSpacing(.08f); summary.addView(label);
        status = Ui.text(this, "Protection is off", 20, true, R.color.pc_text);
        status.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 4)); summary.addView(status);
        enforcement = Ui.text(this, "Best-effort mode · can be bypassed", 13, false, R.color.pc_caution);
        summary.addView(enforcement);
        count = Ui.text(this, "0 apps selected", 14, true, R.color.pc_text);
        count.setPadding(0, Ui.dp(this, 12), 0, 0); summary.addView(count);
        root.addView(summary);

        root.addView(sectionTitle("YOUR BLOCKLIST"));
        root.addView(action("Choose apps", "Select apps and manage your blocklist", true, () -> startActivity(new Intent(this, ProtectedAppsActivity.class))));
        root.addView(sectionTitle("REQUIRED ACCESS"));
        LinearLayout accessCard = Ui.card(this);
        accessibility = Ui.text(this, "Accessibility service · checking…", 15, true, R.color.pc_text);
        accessCard.addView(accessibility);
        accessCard.addView(Ui.button(this, "Open accessibility settings", Ui.SECONDARY));
        accessCard.getChildAt(1).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessCard);

        root.addView(sectionTitle("PREFERENCES"));
        root.addView(action("Settings & appearance", "Theme, blocking switch, status and recovery notes", false, () -> startActivity(new Intent(this, GuardActivity.class))));
        root.addView(action("Diagnostics", "View local event log", false, () -> startActivity(new Intent(this, DiagnosticsActivity.class))));

        TextView note = Ui.text(this, "Private by design · no internet permission · no cloud account", 12, false, R.color.pc_muted);
        note.setGravity(Gravity.CENTER); note.setPadding(0, Ui.dp(this, 18), 0, 0); root.addView(note);
        setContentView(Ui.page(this, root));
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s, 11, true, R.color.pc_muted);
        t.setLetterSpacing(.10f); t.setPadding(2, Ui.dp(this, 18), 0, Ui.dp(this, 8)); return t;
    }
    private View action(String title, String desc, boolean primary, Runnable run) {
        LinearLayout card = Ui.card(this); card.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout copy = Ui.column(this);
        TextView h = Ui.text(this, title, 16, true, R.color.pc_text); copy.addView(h);
        TextView d = Ui.text(this, desc, 13, false, R.color.pc_muted); copy.addView(d);
        card.addView(copy, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView arrow = Ui.text(this, "›", 28, false, R.color.pc_primary); arrow.setGravity(Gravity.CENTER);
        card.addView(arrow, new LinearLayout.LayoutParams(Ui.dp(this, 28), LinearLayout.LayoutParams.MATCH_PARENT));
        card.setClickable(true); card.setFocusable(true); card.setOnClickListener(v -> run.run());
        return card;
    }
    @Override protected void onResume() { super.onResume(); refresh(); }
    private void refresh() {
        int n = Config.protectedPackages(this).size();
        count.setText(n + (n == 1 ? " app selected" : " apps selected"));
        boolean svc = Config.isServiceEnabled(this);
        accessibility.setText("Accessibility service · " + (svc ? "Enabled" : "Not enabled"));
        accessibility.setTextColor(getColor(svc ? R.color.pc_ok : R.color.pc_warn));
        boolean active = Config.isBlockingEnabled(this);
        status.setText(active ? "Best-effort blocking is on" : "Protection is off");
        status.setTextColor(getColor(active ? R.color.pc_ok : R.color.pc_text));
        enforcement.setText(svc && active ? "Best-effort mode · may be bypassed" : "Nothing is blocked until you enable it");
    }
}
