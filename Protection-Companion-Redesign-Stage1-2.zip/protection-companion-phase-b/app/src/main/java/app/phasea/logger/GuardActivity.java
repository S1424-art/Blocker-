package app.phasea.logger;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.content.Intent;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

/** Settings shell. Strong Device Owner policies are intentionally not implemented or activated. */
public class GuardActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        Ui.applyTheme(this);
        super.onCreate(b);
        String theme = getSharedPreferences("protection_companion", MODE_PRIVATE).getString("appearance", "system");
        LinearLayout root = Ui.column(this);
        root.addView(Ui.text(this, "Settings", 26, true, R.color.pc_text));
        root.addView(Ui.text(this, "Control how the companion behaves on this device.", 14, false, R.color.pc_muted));

        LinearLayout appearance = Ui.card(this);
        appearance.addView(Ui.text(this, "Appearance", 17, true, R.color.pc_text));
        RadioGroup themes = new RadioGroup(this); themes.setOrientation(RadioGroup.VERTICAL);
        String[] labels = {"System default", "Light", "Dark"}; String[] values = {"system", "light", "dark"};
        for (int i=0;i<values.length;i++) {
            RadioButton rb = new RadioButton(this); rb.setText(labels[i]); rb.setTag(values[i]); themes.addView(rb);
            if (rb.getId() == -1) rb.setId(1000+i);
        }
        // IDs are assigned above; resolve selected value without relying on platform-generated IDs.
        for (int i=0;i<themes.getChildCount();i++) {
            RadioButton rb=(RadioButton)themes.getChildAt(i);
            if (values[i].equals(theme)) themes.check(rb.getId());
        }
        themes.setOnCheckedChangeListener((group, id) -> {
            for (int i=0;i<group.getChildCount();i++) {
                RadioButton rb=(RadioButton)group.getChildAt(i);
                if (rb.getId()==id) {
                    getSharedPreferences("protection_companion", MODE_PRIVATE).edit().putString("appearance", String.valueOf(rb.getTag())).apply();
                    recreate(); break;
                }
            }
        });
        appearance.addView(themes); root.addView(appearance);

        LinearLayout blocking = Ui.card(this);
        blocking.addView(Ui.text(this, "App blocking", 17, true, R.color.pc_text));
        Switch sw = new Switch(this); sw.setText("Enable best-effort blocking"); sw.setChecked(Config.isBlockingEnabled(this));
        sw.setOnCheckedChangeListener((button, checked) -> Config.setBlockingEnabled(this, checked));
        blocking.addView(sw);
        TextView warning = Ui.text(this, "This mode detects a selected app after it opens and tries to return Home. It is not OS-level enforcement and can be bypassed. Device Owner enforcement is not active in this build.", 13, false, R.color.pc_caution);
        warning.setPadding(0, Ui.dp(this, 8), 0, 0); blocking.addView(warning); root.addView(blocking);

        LinearLayout state = Ui.card(this);
        state.addView(Ui.text(this, "Protection capabilities", 17, true, R.color.pc_text));
        addState(state, "Accessibility", Config.isServiceEnabled(this) ? "Enabled" : "Not active");
        addState(state, "Device Owner", "Not active — not provisioned");
        addState(state, "Uninstall protection", "Not active");
        addState(state, "App suspension", "Not active");
        addState(state, "Settings connectivity exception", "Not implemented / not verified");
        root.addView(state);

        LinearLayout recovery = Ui.card(this);
        recovery.addView(Ui.text(this, "Recovery & privacy", 17, true, R.color.pc_text));
        recovery.addView(Ui.text(this, "Blocking is off by default. This build does not claim to prevent force-stop or uninstall. Keep a way to return to this app and Android settings while testing.", 13, false, R.color.pc_muted));
        android.widget.Button recoveryButton = Ui.button(this, "Open accessibility settings", Ui.SECONDARY);
        recovery.addView(recoveryButton);
        recoveryButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(recovery);
        setContentView(Ui.page(this, root));
    }
    private void addState(LinearLayout box, String k, String v) {
        TextView t=Ui.text(this, k + "\n" + v, 14, false, R.color.pc_text);
        t.setPadding(0, Ui.dp(this, 7), 0, Ui.dp(this, 7)); box.addView(t);
    }
}
