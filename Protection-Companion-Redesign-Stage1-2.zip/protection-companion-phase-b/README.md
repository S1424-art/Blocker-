# Protection Companion — Stage 1/2 development build

This ZIP redesigns the existing Phase B project around the intended general-purpose app-blocker experience. It is a **development build**, not a verified final release.

## Included
- Cleaner home screen and separate settings screen.
- Installed-app picker with app icons, search, and persistent local selection.
- System / Light / Dark appearance choices.
- Best-effort Accessibility redirect when a selected app opens, disabled by default.
- Redirect circuit breaker to pause blocking after repeated actions.
- Explicit capability labels: Device Owner, uninstall protection, and package suspension are not active.
- No internet permission or cloud services.

## Important limits
Accessibility redirection happens after a window event; the selected app may appear briefly and the behavior can be bypassed by disabling Accessibility or other system routes. This is not OS-level app suspension. This build does **not** prevent uninstall or force-stop and does not implement Device Owner provisioning. Settings connectivity exceptions are not implemented. Do not treat any of those capabilities as complete.

## Build
Open this project in GitHub using the existing CI workflow, or build with JDK 17, Gradle 8.7, Android Gradle Plugin 8.5.2, and compileSdk 34. CI output must be inspected to confirm the expected tree was built.

## Suggested test order
1. Install and launch; verify the app picker and icons.
2. Change theme and relaunch the app.
3. Select one harmless app. Leave blocking off and confirm the app still opens.
4. Enable Accessibility, then enable best-effort blocking. Confirm it redirects to Home and that the selected app may flash briefly.
5. Trigger repeated redirects and confirm the circuit breaker disables blocking.
6. Confirm the app's own settings remain reachable and that no Device Owner/uninstall claims are shown as active.
