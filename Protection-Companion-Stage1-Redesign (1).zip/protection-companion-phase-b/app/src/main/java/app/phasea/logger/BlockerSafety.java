package app.phasea.logger;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Conservative package exclusions for the best-effort and Device Owner engines. */
final class BlockerSafety {
    private static final Set<String> NEVER_BLOCK = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
            "com.android.systemui",
            "com.android.settings",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.dialer",
            "com.android.incallui",
            "com.android.contacts",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller",
            "com.android.providers.settings",
            "com.android.providers.telephony",
            "com.android.inputmethod.latin",
            "com.samsung.android.honeyboard"
    )));

    private BlockerSafety() {}

    static boolean isNeverBlock(String packageName, String ownPackage) {
        if (packageName == null || packageName.isEmpty()) return true;
        if (packageName.equals(ownPackage) || NEVER_BLOCK.contains(packageName)) return true;
        String p = packageName.toLowerCase(Locale.ROOT);
        return p.startsWith("com.android.systemui")
                || p.startsWith("com.android.permissioncontroller")
                || p.startsWith("com.google.android.permissioncontroller");
    }

    static boolean isSettingsPackage(String packageName) {
        return "com.android.settings".equals(packageName);
    }
}
