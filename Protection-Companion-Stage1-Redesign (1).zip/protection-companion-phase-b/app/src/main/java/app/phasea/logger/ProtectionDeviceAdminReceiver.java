package app.phasea.logger;

import android.app.admin.DeviceAdminReceiver;

/** Receiver required for Device Owner enrollment. Merely declaring it does not activate policies. */
public final class ProtectionDeviceAdminReceiver extends DeviceAdminReceiver {
}
