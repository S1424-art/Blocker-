package app.phasea.logger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Optional diagnostics. Logs stay in app-private storage and can be cleared at any time. */
public class DiagnosticsActivity extends Activity {
    private static final int VIEW_LINES = 150;
    private TextView status;
    private TextView logView;
    private Button toggleButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Ui.prepareTheme(this);
        super.onCreate(savedInstanceState);
        Ui.applyWindowColors(this);

        LinearLayout content = Ui.column(this);
        content.addView(Ui.title(this, "Diagnostics"));
        content.addView(Ui.subtitle(this,
                "Optional local log for troubleshooting. Package and activity names may appear; screen body text is not written to the log."));

        LinearLayout statusCard = Ui.card(this);
        status = Ui.text(this, "", 14, false, R.color.pc_text);
        statusCard.addView(status);
        statusCard.addView(actionButton("Open Accessibility settings", Ui.SECONDARY,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        toggleButton = actionButton("Pause logging", Ui.SECONDARY, v -> {
            boolean next = !LogStore.isEnabled(this);
            LogStore.setEnabled(this, next);
            if (next) LogStore.append(this, "LOGGING resumed");
            refresh();
        });
        statusCard.addView(toggleButton);
        content.addView(statusCard);

        LinearLayout logCard = Ui.card(this);
        logCard.addView(Ui.text(this, "Recent entries", 17, true, R.color.pc_text));
        logCard.addView(Ui.text(this, "The log is capped at approximately 400 KB and is never uploaded.",
                12, false, R.color.pc_muted));
        logCard.addView(actionButton("Refresh", Ui.SECONDARY, v -> refresh()));
        logCard.addView(actionButton("Copy last " + VIEW_LINES + " lines", Ui.SECONDARY, v -> {
            ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            manager.setPrimaryClip(ClipData.newPlainText("protection-companion-log", LogStore.tail(this, VIEW_LINES)));
            Toast.makeText(this, "Copied. Review it before sharing.", Toast.LENGTH_SHORT).show();
        }));
        logCard.addView(actionButton("Clear log", Ui.DANGER, v -> new AlertDialog.Builder(this)
                .setTitle("Clear diagnostics?")
                .setMessage("This permanently deletes the local diagnostics log. It does not change the app blocklist or policy state.")
                .setPositiveButton("Clear", (dialog, which) -> {
                    LogStore.clear(this);
                    refresh();
                })
                .setNegativeButton("Cancel", null)
                .show()));

        logView = new TextView(this);
        logView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        logView.setTextColor(Ui.color(this, R.color.pc_text));
        logView.setTextIsSelectable(true);
        logView.setTypeface(android.graphics.Typeface.MONOSPACE);
        logView.setEllipsize(TextUtils.TruncateAt.END);
        logView.setPadding(0, Ui.dp(this, 12), 0, 0);
        logCard.addView(logView);
        content.addView(logCard);
        content.addView(actionButton("Back", Ui.QUIET, v -> finish()));
        setContentView(Ui.page(this, content));
        refresh();
    }

    private Button actionButton(String label, int style, android.view.View.OnClickListener listener) {
        Button button = Ui.button(this, label, style);
        button.setOnClickListener(listener);
        return button;
    }

    @Override
    protected void onResume() {
        super.onResume();
        Ui.applyWindowColors(this);
        refresh();
    }

    private void refresh() {
        if (status == null || logView == null || toggleButton == null) return;
        boolean enabled = LogStore.isEnabled(this);
        toggleButton.setText(enabled ? "Pause logging" : "Resume logging");
        status.setText("Accessibility service: " + (Config.isServiceEnabled(this) ? "enabled" : "not enabled")
                + "\nBest-effort blocking: " + (Config.isBlockingEnabled(this) ? "on" : "off")
                + "\nDevice Owner: " + (DevicePolicyController.isDeviceOwner(this) ? "active" : "not active")
                + "\nLogging: " + (enabled ? "on" : "paused")
                + "\nLog size: " + (LogStore.sizeBytes(this) / 1024) + " KB");
        String recent = LogStore.tail(this, VIEW_LINES);
        logView.setText(recent.isEmpty() ? "(No log entries yet)" : recent);
    }
}
