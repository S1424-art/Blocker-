package app.phasea.logger;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Local-only app PIN. The raw PIN is never persisted or written to diagnostics. */
final class AppLockManager {
    enum VerifyResult { SUCCESS, INCORRECT, TEMPORARILY_LOCKED, NOT_CONFIGURED }

    private static final String PREFS = "protection_companion_app_lock";
    private static final String K_ENABLED = "enabled";
    private static final String K_SALT = "salt";
    private static final String K_HASH = "hash";
    private static final String K_FAILURES = "failures";
    private static final String K_LOCK_UNTIL = "lock_until_wall_ms";
    private static final int ITERATIONS = 150_000;
    private static final int HASH_BITS = 256;
    private static final int SALT_BYTES = 16;
    private static final int MAX_FAILURES = 5;
    private static final long LOCKOUT_MS = 30_000L;

    private static volatile boolean sessionUnlocked;

    private AppLockManager() { }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isConfigured(Context context) {
        SharedPreferences p = prefs(context);
        return p.contains(K_SALT) && p.contains(K_HASH);
    }

    static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(K_ENABLED, false) && isConfigured(context);
    }

    static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(K_ENABLED, enabled && isConfigured(context)).apply();
        LogStore.log(context, "APP_LOCK enabled=" + (enabled && isConfigured(context)));
        if (!enabled) sessionUnlocked = false;
    }

    static void clearPin(Context context) {
        prefs(context).edit().remove(K_SALT).remove(K_HASH).remove(K_FAILURES).remove(K_LOCK_UNTIL)
                .putBoolean(K_ENABLED, false).apply();
        sessionUnlocked = false;
        LogStore.log(context, "APP_LOCK PIN reset through device-credential recovery");
    }

    static boolean hasSecureScreenLock(Context context) {
        KeyguardManager manager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        return manager != null && manager.isDeviceSecure();
    }

    static void setPin(Context context, String pin) throws GeneralSecurityException {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] derived = derive(pin.toCharArray(), salt);
        prefs(context).edit()
                .putString(K_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString(K_HASH, Base64.encodeToString(derived, Base64.NO_WRAP))
                .putInt(K_FAILURES, 0)
                .remove(K_LOCK_UNTIL)
                .apply();
        LogStore.log(context, "APP_LOCK PIN configured; value not logged");
    }

    static VerifyResult verifyPin(Context context, String candidate) {
        SharedPreferences p = prefs(context);
        if (!isConfigured(context)) return VerifyResult.NOT_CONFIGURED;
        long lockUntil = p.getLong(K_LOCK_UNTIL, 0L);
        long now = System.currentTimeMillis();
        if (lockUntil > now) return VerifyResult.TEMPORARILY_LOCKED;
        try {
            byte[] salt = Base64.decode(p.getString(K_SALT, ""), Base64.NO_WRAP);
            byte[] expected = Base64.decode(p.getString(K_HASH, ""), Base64.NO_WRAP);
            byte[] actual = derive(candidate.toCharArray(), salt);
            if (MessageDigest.isEqual(expected, actual)) {
                p.edit().putInt(K_FAILURES, 0).remove(K_LOCK_UNTIL).apply();
                return VerifyResult.SUCCESS;
            }
        } catch (IllegalArgumentException | GeneralSecurityException e) {
            LogStore.log(context, "APP_LOCK verification error=" + e.getClass().getSimpleName());
            return VerifyResult.NOT_CONFIGURED;
        }
        int failures = p.getInt(K_FAILURES, 0) + 1;
        if (failures >= MAX_FAILURES) {
            p.edit().putInt(K_FAILURES, 0).putLong(K_LOCK_UNTIL, now + LOCKOUT_MS).apply();
            LogStore.log(context, "APP_LOCK temporary lockout activated");
            return VerifyResult.TEMPORARILY_LOCKED;
        }
        p.edit().putInt(K_FAILURES, failures).apply();
        return VerifyResult.INCORRECT;
    }

    static long remainingLockoutMs(Context context) {
        long remaining = prefs(context).getLong(K_LOCK_UNTIL, 0L) - System.currentTimeMillis();
        return Math.max(0L, remaining);
    }

    static boolean isSessionUnlocked() {
        return sessionUnlocked;
    }

    static void unlockSession(Context context) {
        sessionUnlocked = true;
        LogStore.log(context, "APP_LOCK session unlocked");
    }

    static void lockSession() {
        sessionUnlocked = false;
    }

    private static byte[] derive(char[] pin, byte[] salt) throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(pin, salt, ITERATIONS, HASH_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
            java.util.Arrays.fill(pin, '\0');
        }
    }
}
