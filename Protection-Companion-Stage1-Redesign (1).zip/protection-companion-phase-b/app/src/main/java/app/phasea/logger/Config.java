package app.phasea.logger;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import java.util.HashSet;
import java.util.Set;

/** Private, local-only product preferences. No preference is uploaded or synced. */
final class Config {
    enum Appearance { SYSTEM, LIGHT, DARK }

    private static final String PREFS = "protection_companion";
    private static final String K_PKGS = "protected_pkgs"; // kept compatible with the Phase B prototype
    private static final String K_LABEL = "label.";
    private static final String K_BLOCKING = "blocking_enabled";
    private static final String K_FALLBACK_PAUSED = "fallback_paused_for_safety";
    private static final String K_SETTINGS_GUARD = "settings_guard_enabled";
    private static final String K_APPEARANCE = "appearance";
    private static final String K_SYSTEM_ENFORCEMENT = "system_enforcement_enabled";
    private static final String K_MANAGED_PACKAGES = "system_managed_packages";

    private Config() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Set<String> protectedPackages(Context c) {
        Set<String> stored = prefs(c).getStringSet(K_PKGS, null);
        return stored == null ? new HashSet<>() : new HashSet<>(stored);
    }

    static Set<String> blockedPackages(Context c) {
        return protectedPackages(c);
    }

    /** Remove entries from the legacy Phase B picker that are unsafe or handled separately. */
    static void sanitizeBlocklist(Context c) {
        Set<String> packages = protectedPackages(c);
        boolean changed = packages.remove(c.getPackageName());
        changed |= packages.remove("com.android.settings");
        for (String pkg : new HashSet<>(packages)) {
            if (BlockerSafety.isNeverBlock(pkg, c.getPackageName())) {
                changed |= packages.remove(pkg);
            }
        }
        if (changed) {
            prefs(c).edit().putStringSet(K_PKGS, packages).apply();
            LogStore.log(c, "CONFIG removed unsafe legacy blocklist entries");
            // Startup sanitation only repairs local preferences. It never applies system policy.
        }
    }

    static boolean isProtected(Context c, String pkg) {
        return protectedPackages(c).contains(pkg);
    }

    static String label(Context c, String pkg) {
        return prefs(c).getString(K_LABEL + pkg, pkg);
    }

    static DevicePolicyController.Result setProtected(Context c, String pkg, String label, boolean on) {
        if (pkg == null || pkg.trim().isEmpty() || pkg.equals(c.getPackageName())
                || BlockerSafety.isNeverBlock(pkg, c.getPackageName())
                || BlockerSafety.isSettingsPackage(pkg)) {
            return new DevicePolicyController.Result(false, "This app is excluded from the blocklist for safety.");
        }
        Set<String> packages = protectedPackages(c);
        SharedPreferences.Editor editor = prefs(c).edit();
        if (on) {
            packages.add(pkg);
            editor.putString(K_LABEL + pkg, label == null || label.trim().isEmpty() ? pkg : label.trim());
        } else {
            packages.remove(pkg);
            editor.remove(K_LABEL + pkg);
        }
        editor.putStringSet(K_PKGS, packages).apply();
        LogStore.log(c, "CONFIG blocklist " + (on ? "add " : "remove ") + pkg);
        if (DevicePolicyController.isDeviceOwner(c) && isSystemEnforcementEnabled(c)) {
            if (packages.isEmpty()) {
                DevicePolicyController.Result result = DevicePolicyController.syncSuspensions(c, false);
                if (result.ok) {
                    setSystemEnforcementEnabled(c, false);
                    setBlockingEnabled(c, false);
                }
                return result;
            }
            return DevicePolicyController.syncSuspensions(c, true);
        }
        return null;
    }

    static boolean isBlockingEnabled(Context c) {
        return prefs(c).getBoolean(K_BLOCKING, false);
    }

    static void setBlockingEnabled(Context c, boolean on) {
        prefs(c).edit().putBoolean(K_BLOCKING, on).apply();
        LogStore.log(c, "BLOCKING requested=" + on);
    }

    static boolean isFallbackPaused(Context c) {
        return prefs(c).getBoolean(K_FALLBACK_PAUSED, false);
    }

    static void setFallbackPaused(Context c, boolean paused) {
        prefs(c).edit().putBoolean(K_FALLBACK_PAUSED, paused).apply();
        LogStore.log(c, "FALLBACK_PAUSED=" + paused);
    }

    static boolean isSettingsGuardEnabled(Context c) {
        return prefs(c).getBoolean(K_SETTINGS_GUARD, false);
    }

    static void setSettingsGuardEnabled(Context c, boolean on) {
        prefs(c).edit().putBoolean(K_SETTINGS_GUARD, on).apply();
        LogStore.log(c, "SETTINGS_GUARD best_effort=" + on);
    }

    static Appearance appearance(Context c) {
        String stored = prefs(c).getString(K_APPEARANCE, Appearance.SYSTEM.name());
        try {
            return Appearance.valueOf(stored);
        } catch (IllegalArgumentException e) {
            return Appearance.SYSTEM;
        }
    }

    static void setAppearance(Context c, Appearance value) {
        prefs(c).edit().putString(K_APPEARANCE, value.name()).apply();
    }

    static boolean isSystemEnforcementEnabled(Context c) {
        return prefs(c).getBoolean(K_SYSTEM_ENFORCEMENT, false);
    }

    static void setSystemEnforcementEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean(K_SYSTEM_ENFORCEMENT, enabled).apply();
    }

    static Set<String> managedPackages(Context c) {
        Set<String> stored = prefs(c).getStringSet(K_MANAGED_PACKAGES, null);
        return stored == null ? new HashSet<>() : new HashSet<>(stored);
    }

    static void setManagedPackages(Context c, Set<String> packages) {
        prefs(c).edit().putStringSet(K_MANAGED_PACKAGES, new HashSet<>(packages)).apply();
    }

    static boolean isServiceEnabled(Context c) {
        String enabled = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(c, LoggerService.class);
        return enabled.contains(me.flattenToString()) || enabled.contains(me.flattenToShortString());
    }
}
