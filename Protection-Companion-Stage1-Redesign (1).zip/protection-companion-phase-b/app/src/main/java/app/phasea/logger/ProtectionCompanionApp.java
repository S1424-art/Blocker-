package app.phasea.logger;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

/** Locks the UI when the app leaves the foreground, without adding a background service. */
public final class ProtectionCompanionApp extends Application
        implements Application.ActivityLifecycleCallbacks {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int startedActivities;
    private boolean backgroundPending;
    private boolean gateLaunchPending;

    private final Runnable backgroundLock = () -> {
        if (startedActivities == 0 && backgroundPending) {
            if (AppLockManager.isEnabled(this)) AppLockManager.lockSession();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
    }

    @Override public void onActivityStarted(Activity activity) {
        if (startedActivities == 0) {
            handler.removeCallbacks(backgroundLock);
            if (backgroundPending && AppLockManager.isEnabled(this)) {
                AppLockManager.lockSession();
            }
            backgroundPending = false;
        }
        startedActivities++;
    }

    @Override public void onActivityStopped(Activity activity) {
        startedActivities = Math.max(0, startedActivities - 1);
        if (startedActivities == 0) {
            backgroundPending = true;
            handler.removeCallbacks(backgroundLock);
            handler.postDelayed(backgroundLock, 650L);
        }
    }

    @Override public void onActivityResumed(Activity activity) {
        if (activity instanceof AppLockActivity || !AppLockManager.isEnabled(this)
                || AppLockManager.isSessionUnlocked() || gateLaunchPending) return;
        gateLaunchPending = true;
        handler.post(() -> {
            if (activity.isFinishing() || activity.isDestroyed()
                    || !AppLockManager.isEnabled(this) || AppLockManager.isSessionUnlocked()) {
                gateLaunchPending = false;
                return;
            }
            try {
                activity.startActivity(new Intent(activity, AppLockActivity.class));
            } catch (RuntimeException e) {
                gateLaunchPending = false;
                LogStore.log(this, "APP_LOCK gate launch failed=" + e.getClass().getSimpleName());
            }
        });
    }

    @Override public void onActivityCreated(Activity activity, android.os.Bundle state) { }
    @Override public void onActivityPaused(Activity activity) { }
    @Override public void onActivitySaveInstanceState(Activity activity, android.os.Bundle state) { }
    @Override public void onActivityDestroyed(Activity activity) {
        if (activity instanceof AppLockActivity && !activity.isChangingConfigurations()) {
            gateLaunchPending = false;
        }
    }
}
