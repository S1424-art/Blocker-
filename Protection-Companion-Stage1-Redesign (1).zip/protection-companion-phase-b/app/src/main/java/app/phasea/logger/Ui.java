package app.phasea.logger;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Compact native UI system: spacing, rounded surfaces, typography, and user-selectable themes. */
final class Ui {
    static final int PRIMARY = 0;
    static final int SECONDARY = 1;
    static final int DANGER = 2;
    static final int QUIET = 3;

    private Ui() {}

    static int dp(Context c, int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                c.getResources().getDisplayMetrics());
    }

    static void prepareTheme(Activity activity) {
        Config.Appearance appearance = Config.appearance(activity);
        boolean dark;
        if (appearance == Config.Appearance.SYSTEM) {
            int mode = activity.getResources().getConfiguration().uiMode
                    & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            dark = mode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        } else {
            dark = appearance == Config.Appearance.DARK;
        }
        activity.setTheme(dark ? android.R.style.Theme_Material_NoActionBar
                : android.R.style.Theme_Material_Light_NoActionBar);
    }

    static void applyWindowColors(Activity activity) {
        Window window = activity.getWindow();
        boolean dark = isDark(activity);
        window.setStatusBarColor(color(activity, R.color.pc_bg));
        window.setNavigationBarColor(color(activity, R.color.pc_bg));
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (!dark) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        window.getDecorView().setSystemUiVisibility(flags);
    }

    static boolean isDark(Context c) {
        Config.Appearance appearance = Config.appearance(c);
        if (appearance == Config.Appearance.DARK) return true;
        if (appearance == Config.Appearance.LIGHT) return false;
        int mode = c.getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return mode == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    /** Resolve the app's palette independently of Android's system night-mode resource loading. */
    static int color(Context c, int resourceId) {
        boolean dark = isDark(c);
        if (resourceId == R.color.pc_bg) return android.graphics.Color.parseColor(dark ? "#101418" : "#F4F6FA");
        if (resourceId == R.color.pc_surface) return android.graphics.Color.parseColor(dark ? "#1B2229" : "#FFFFFF");
        if (resourceId == R.color.pc_stroke) return android.graphics.Color.parseColor(dark ? "#35414B" : "#DFE5EC");
        if (resourceId == R.color.pc_primary) return android.graphics.Color.parseColor(dark ? "#B9D5FF" : "#24476A");
        if (resourceId == R.color.pc_on_primary) return android.graphics.Color.parseColor(dark ? "#102033" : "#FFFFFF");
        if (resourceId == R.color.pc_text) return android.graphics.Color.parseColor(dark ? "#F0F3F6" : "#18212B");
        if (resourceId == R.color.pc_muted) return android.graphics.Color.parseColor(dark ? "#A8B4C0" : "#5C6A78");
        if (resourceId == R.color.pc_ok) return android.graphics.Color.parseColor(dark ? "#82D6A8" : "#1D7A4E");
        if (resourceId == R.color.pc_warn) return android.graphics.Color.parseColor(dark ? "#FFB4AB" : "#B3261E");
        if (resourceId == R.color.pc_caution) return android.graphics.Color.parseColor(dark ? "#F2C66D" : "#8A5A00");
        return c.getColor(resourceId);
    }

    static LinearLayout column(Context c) {
        LinearLayout layout = new LinearLayout(c);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    static LinearLayout row(Context c) {
        LinearLayout layout = new LinearLayout(c);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    static ScrollView page(Context c, LinearLayout content) {
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(color(c, R.color.pc_bg));
        int pad = dp(c, 18);
        content.setPadding(pad, pad, pad, pad + dp(c, 12));
        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    static TextView text(Context c, CharSequence value, int sizeSp, boolean bold, int colorRes) {
        TextView text = new TextView(c);
        text.setText(value);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp);
        text.setTextColor(color(c, colorRes));
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text.setLineSpacing(dp(c, 2), 1f);
        text.setPadding(0, 0, 0, dp(c, 4));
        return text;
    }

    static TextView title(Context c, CharSequence value) {
        TextView title = text(c, value, 25, true, R.color.pc_text);
        title.setPadding(0, 0, 0, dp(c, 3));
        return title;
    }

    static TextView subtitle(Context c, CharSequence value) {
        TextView subtitle = text(c, value, 14, false, R.color.pc_muted);
        subtitle.setPadding(0, 0, 0, dp(c, 12));
        return subtitle;
    }

    static LinearLayout card(Context c) {
        LinearLayout card = column(c);
        GradientDrawable background = new GradientDrawable();
        background.setColor(color(c, R.color.pc_surface));
        background.setCornerRadius(dp(c, 18));
        background.setStroke(dp(c, 1), color(c, R.color.pc_stroke));
        card.setBackground(background);
        card.setElevation(dp(c, 1));
        int pad = dp(c, 15);
        card.setPadding(pad, pad, pad, pad);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(c, 12));
        card.setLayoutParams(lp);
        return card;
    }

    static Button button(Context c, CharSequence label, int style) {
        Button button = new Button(c);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        button.setMinHeight(dp(c, 48));
        button.setMinimumHeight(dp(c, 48));
        button.setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8));
        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(c, 14));
        if (style == PRIMARY) {
            background.setColor(color(c, R.color.pc_primary));
            button.setTextColor(color(c, R.color.pc_on_primary));
        } else if (style == DANGER) {
            background.setColor(color(c, R.color.pc_warn));
            button.setTextColor(color(c, R.color.pc_on_primary));
        } else if (style == QUIET) {
            background.setColor(color(c, R.color.pc_bg));
            button.setTextColor(color(c, R.color.pc_text));
        } else {
            background.setColor(color(c, R.color.pc_surface));
            background.setStroke(dp(c, 1), color(c, R.color.pc_stroke));
            button.setTextColor(color(c, R.color.pc_primary));
        }
        button.setBackground(background);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(c, 7), 0, 0);
        button.setLayoutParams(lp);
        return button;
    }

    static TextView pill(Context c, CharSequence label, int colorRes) {
        TextView pill = text(c, label, 12, true, colorRes);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color(c, R.color.pc_bg));
        bg.setCornerRadius(dp(c, 99));
        bg.setStroke(dp(c, 1), color(c, R.color.pc_stroke));
        pill.setBackground(bg);
        return pill;
    }

    static TextView valueRow(Context c, LinearLayout parent, String label) {
        LinearLayout row = row(c);
        row.setPadding(0, dp(c, 6), 0, dp(c, 6));
        TextView labelView = text(c, label, 14, false, R.color.pc_muted);
        TextView value = text(c, "", 14, true, R.color.pc_text);
        value.setGravity(Gravity.END);
        row.addView(labelView, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value, new LinearLayout.LayoutParams(0, -2, 1f));
        parent.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return value;
    }

    static void space(Context c, LinearLayout parent, int heightDp) {
        View spacer = new View(c);
        parent.addView(spacer, new LinearLayout.LayoutParams(1, dp(c, heightDp)));
    }
}
