package app.phasea.logger;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Private, local-only log file plus two small settings. Nothing here leaves the phone. */
final class LogStore {

    private static final String FILE_NAME = "diag-stage1.log";
    private static final long MAX_BYTES = 400_000L;
    private static final Object LOCK = new Object();
    private static final DateTimeFormatter TS =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private LogStore() {}

    // ---- settings -------------------------------------------------------

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("protection_companion", Context.MODE_PRIVATE);
    }

    private static final String K_LOGGING_ENABLED = "stage1_diagnostics_enabled";

    static boolean isEnabled(Context c) {
        return prefs(c).getBoolean(K_LOGGING_ENABLED, false);
    }

    static void setEnabled(Context c, boolean on) {
        prefs(c).edit().putBoolean(K_LOGGING_ENABLED, on).apply();
    }

    /** Appends only when logging is not paused. */
    static void log(Context c, String line) {
        if (isEnabled(c)) append(c, line);
    }

    // ---- log file -------------------------------------------------------

    private static File file(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), FILE_NAME);
    }

    static void append(Context c, String line) {
        synchronized (LOCK) {
            File f = file(c);
            String out = LocalDateTime.now().format(TS) + " " + line + "\n";
            try (FileOutputStream os = new FileOutputStream(f, true)) {
                os.write(out.getBytes(StandardCharsets.UTF_8));
            } catch (IOException ignored) {
                return;
            }
            if (f.length() > MAX_BYTES) trim(f);
        }
    }

    /** Keep roughly the newest half of the file, cut at a line boundary. */
    private static void trim(File f) {
        try {
            String all = readAll(f);
            int cut = all.indexOf('\n', all.length() / 2);
            String keep = cut >= 0 ? all.substring(cut + 1) : "";
            try (FileOutputStream os = new FileOutputStream(f, false)) {
                os.write(keep.getBytes(StandardCharsets.UTF_8));
            }
        } catch (IOException ignored) {
        }
    }

    private static String readAll(File f) throws IOException {
        if (!f.exists()) return "";
        try (FileInputStream is = new FileInputStream(f);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    static String tail(Context c, int maxLines) {
        synchronized (LOCK) {
            try {
                String all = readAll(file(c));
                if (all.isEmpty()) return "";
                String[] lines = all.split("\n");
                int start = Math.max(0, lines.length - maxLines);
                StringBuilder sb = new StringBuilder();
                for (int i = start; i < lines.length; i++) sb.append(lines[i]).append('\n');
                return sb.toString();
            } catch (IOException e) {
                return "";
            }
        }
    }

    static long sizeBytes(Context c) {
        return file(c).length();
    }

    static void clear(Context c) {
        synchronized (LOCK) {
            File f = file(c);
            if (f.exists()) f.delete();
        }
    }
}
