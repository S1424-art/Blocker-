package app.phasea.logger;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** The app-local PIN gate. It never modifies the Android device lock or Device Owner state. */
public final class AppLockActivity extends Activity {
    private EditText pinInput;
    private TextView message;
    private static final int REQUEST_DEVICE_CREDENTIAL = 7413;

    @Override protected void onCreate(Bundle state) {
        Ui.prepareTheme(this);
        super.onCreate(state);
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE);
        Ui.applyWindowColors(this);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        LinearLayout content = Ui.column(this);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.addView(Ui.title(this, "Protection Companion"));
        content.addView(Ui.subtitle(this, "Enter your app PIN to continue."));
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "App locked", 19, true, R.color.pc_text));
        card.addView(Ui.text(this, "This PIN protects access to the app's settings and blocklist. It is separate from Android's uninstall-protection policy.",
                13, false, R.color.pc_muted));
        pinInput = new EditText(this);
        pinInput.setSingleLine(true);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        pinInput.setHint("6–12 digit PIN");
        pinInput.setTextSize(20);
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setSelectAllOnFocus(true);
        pinInput.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        card.addView(pinInput);
        message = Ui.text(this, "", 13, false, R.color.pc_muted);
        message.setPadding(0, Ui.dp(this, 6), 0, 0);
        card.addView(message);
        card.addView(actionButton("Unlock", Ui.PRIMARY, v -> tryUnlock()));
        card.addView(actionButton("Forgot PIN? Use phone screen lock", Ui.SECONDARY,
                v -> recoverWithDeviceCredential()));
        content.addView(card);
        setContentView(Ui.page(this, content));
        pinInput.requestFocus();
        pinInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                tryUnlock();
                return true;
            }
            return false;
        });
        updateLockoutMessage();
    }

    private android.widget.Button actionButton(String label, int style, android.view.View.OnClickListener listener) {
        android.widget.Button button = Ui.button(this, label, style);
        button.setOnClickListener(listener);
        return button;
    }

    private void tryUnlock() {
        if (AppLockManager.remainingLockoutMs(this) > 0) {
            updateLockoutMessage();
            return;
        }
        String pin = pinInput.getText() == null ? "" : pinInput.getText().toString();
        if (pin.length() < 6 || pin.length() > 12) {
            pinInput.setError("Enter your 6–12 digit PIN");
            return;
        }
        AppLockManager.VerifyResult result = AppLockManager.verifyPin(this, pin);
        pinInput.setText("");
        if (result == AppLockManager.VerifyResult.SUCCESS) {
            AppLockManager.unlockSession(this);
            Intent home = new Intent(this, MainActivity.class);
            home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(home);
            finish();
        } else if (result == AppLockManager.VerifyResult.TEMPORARILY_LOCKED) {
            updateLockoutMessage();
        } else {
            message.setText(result == AppLockManager.VerifyResult.NOT_CONFIGURED
                    ? "The PIN is unavailable. Use phone screen-lock recovery if configured."
                    : "Incorrect PIN. After five failed attempts, entry pauses for 30 seconds.");
            message.setTextColor(Ui.color(this, R.color.pc_warn));
        }
    }

    private void updateLockoutMessage() {
        long remaining = AppLockManager.remainingLockoutMs(this);
        if (message == null) return;
        if (remaining > 0) {
            message.setText("Try again in " + Math.max(1L, (remaining + 999L) / 1000L) + " seconds.");
            message.setTextColor(Ui.color(this, R.color.pc_caution));
        } else {
            message.setText("");
        }
    }

    private void recoverWithDeviceCredential() {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (keyguard == null || !keyguard.isDeviceSecure()) {
            new AlertDialog.Builder(this)
                    .setTitle("Phone screen lock required")
                    .setMessage("PIN recovery uses Android's own screen-lock verification. No secure screen lock is configured right now. If you have not forgotten your app PIN, cancel and enter it. For future recovery, configure a secure screen lock in Android Settings before enabling App lock.")
                    .setPositiveButton("Security settings", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
                        } catch (RuntimeException e) {
                            Toast.makeText(this, "Could not open security settings.", Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        Intent credential = keyguard.createConfirmDeviceCredentialIntent(
                "Unlock Protection Companion", "Confirm your phone screen lock to continue");
        if (credential == null) {
            Toast.makeText(this, "Android could not open screen-lock verification.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivityForResult(credential, REQUEST_DEVICE_CREDENTIAL);
        } catch (RuntimeException e) {
            Toast.makeText(this, "Screen-lock recovery is unavailable on this device.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_DEVICE_CREDENTIAL && resultCode == RESULT_OK) {
            AppLockManager.clearPin(this);
            AppLockManager.unlockSession(this);
            Toast.makeText(this, "Recovery verified. The forgotten app PIN was reset; set a new one in Settings if needed.",
                    Toast.LENGTH_LONG).show();
            Intent home = new Intent(this, MainActivity.class);
            home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(home);
            finish();
        }
    }

    @Override public void onBackPressed() {
        // Stay on the lock screen; Home is still available through the Android system navigation.
    }
}
