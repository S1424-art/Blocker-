# Recovery notes — Protection Companion

## App PIN lock

- The app PIN is local-only and is stored as a salted PBKDF2-HMAC-SHA256 hash. The raw PIN is never written to logs.
- Configure a secure Android screen lock before enabling the app PIN. The **Forgot PIN?** path uses Android's device-credential confirmation to reopen the app session. It does not reveal or change the app PIN; enter Settings to change or disable the app lock afterward.
- Five consecutive incorrect PIN attempts trigger a 30-second pause.
- The app PIN only gates this app's UI. It does not stop Android from uninstalling the app, clearing its data, force-stopping it, or disabling Accessibility.
- If the device screen lock is removed after app PIN setup, forgotten-PIN recovery may become unavailable. Keep a secure screen lock configured.

## Uninstall protection

A normal app installation cannot enforce uninstall blocking. The app calls `DevicePolicyManager.setUninstallBlocked()` only when Android reports this package as Device Owner. Installing the APK, enabling Accessibility, or activating legacy Device Admin alone does not make the strong uninstall-block policy active.

No Device Owner provisioning is performed by this source build. Before attempting enrollment on a personal phone, confirm the exact Android/Samsung prerequisites and rehearse a recovery route. Device Owner policies can be difficult to remove; some recovery routes erase internal data. Do not remove accounts, provision ownership, or apply other system restrictions as part of ordinary app installation.

The uninstall switch is intentionally disabled until Device Owner is active, and its status is based on Android read-back rather than the UI switch alone.
