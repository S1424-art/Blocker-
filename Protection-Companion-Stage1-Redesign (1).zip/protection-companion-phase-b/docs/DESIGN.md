# Design: Protection Companion — redesigned Stage 1

## Goal

A simple, persistent, local-only app blocker. The user chooses applications on Home and can enable or disable blocking without a lease or timer. BlockerX is not special-cased.

## Architecture

| File | Purpose |
|---|---|
| `MainActivity` | Home, searchable launcher-app list, saved blocklist, overall on/off control |
| `SettingsActivity` | Themes, Accessibility status, optional Settings screen gate, policy status and explicit Device Owner-only controls |
| `LoggerService` | Local diagnostics, best-effort app redirection, optional Settings screen gate |
| `Config` | Persistent private preferences for blocklist, toggles, theme, and policy ledger |
| `BlockerSafety` | Never-block list for this app and essential Android packages |
| `DevicePolicyController` | Checks Device Owner/read-back and applies policies only after an explicit in-app request by an already-enrolled owner |
| `ProtectionDeviceAdminReceiver` | Receiver declaration required for a future Device Owner testing stage; declaration alone does not make the app Device Owner |
| `LogStore` | Private local diagnostic file, capped at roughly 400 KB |
| `Ui` | Shared typography, spacing, rounded surfaces and System/Light/Dark color palette |
| `ConnectivityActivity` | Opens ordinary connectivity screens for manual tests |
| `DiagnosticsActivity` | View/copy/clear local logs and pause/resume logging |

## App blocking

### Accessibility fallback

When the user enables blocking and the Accessibility service is enabled, a window-state event for a selected application triggers the system Home action. This occurs after the application's window begins to appear. It is a best-effort redirect, not a reliable package suspension. The service does not inspect screen text for selected apps.

### Device Owner policy path

If and only if Android reports this app is Device Owner, the Settings screen exposes two explicit operations:

- `setPackagesSuspended` for the selected user-app blocklist, with a ledger of packages managed by this app and read-back of actual package suspension.
- `setUninstallBlocked` for this app, with read-back of actual policy state.

No policies are applied at startup. The user must confirm each enforcement switch. The in-app release operation requests unsuspension of packages from this app's ledger and removes the uninstall block. It does not remove Device Owner enrollment. These methods are not tested on the target phone in this workspace.

Android may refuse to suspend important packages, including the active launcher, the required package installer/uninstaller/verifier, default dialer, and permission controller. This implementation additionally excludes the app itself, Android Settings, and several essential packages.

## Android Settings exception

Android/Samsung does not offer a supported API to suspend individual screens inside one Settings package. The optional Accessibility-based screen gate is off by default and attempts to preserve known connectivity and recovery routes. It inspects currently visible Settings labels in memory only; it does not persist or log those labels. One UI can route multiple pages through a shared activity, so this behavior is experimental and not reliable enough for a security boundary. Android Settings is never suspended by the Device Owner blocklist in this release.

## Data and privacy

- No `INTERNET` or `QUERY_ALL_PACKAGES` permission.
- The picker queries launcher-visible applications.
- The foreground package and activity class may be stored in the private diagnostics log when logging is enabled. Review the log before sharing it.
- Settings screen labels are inspected in memory only when the optional gate is active; text is not written to the log.
- Preferences and diagnostic log remain in app-private storage.

## What remains unverified

- Compilation and APK integrity are checked in GitHub Actions, not by this workspace.
- Accessibility timings and One UI activity names need tests on the actual Samsung A32 5G.
- Device Owner enrollment, package suspension, uninstall policy, failure results, and recovery must be rehearsed separately before using those controls.
- This is not a final hardened product.
