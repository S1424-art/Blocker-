# Protection Companion — redesigned Stage 1

A local-only Android app blocker prototype for Android 13 / One UI. The product is a **general-purpose app blocker**: BlockerX is simply one possible selection, not a special dependency.

## What's changed in this revision

- The Home screen is the app picker: icons, labels, search, a blocked-app count, and a persistent blocklist.
- Blocking has one on/off control and no ARM duration or timer.
- Light, dark, and system themes are available from a separate Settings screen.
- Accessibility fallback reacts to a selected app after its window appears and returns Home. This is **best-effort**, not an OS-level block; the app may flash briefly, and Accessibility can be disabled.
- The Settings-screen gate is optional and off by default. Samsung may use a shared activity for many Settings pages, so connectivity/recovery exceptions are not guaranteed.
- The package picker deduplicates apps with more than one launcher activity. A safety circuit breaker pauses the Accessibility fallback after repeated redirects and shows a separate status rather than silently claiming system policy was turned off.
- A Device Owner receiver and policy controller are present. On a normal installation, Device Owner is not active and the system-policy controls remain disabled. The app does not provision itself or apply policies at startup.
- Device Owner-only controls are explicit, display system read-backs, and include an in-app attempt to release app-level suspension and uninstall policies. This does **not** remove Device Owner enrollment.
- The app requests no internet permission and does not upload logs or preferences.

## Important scope limits

This is a development build, not a final hardened release. The strong uninstall-protection requirement is **not active on an ordinary installation**. It requires a separately reviewed Device Owner enrollment/recovery stage, plus tests on the target Samsung phone. Do not treat the existence of a switch, API call, or green CI build as proof of enforcement.

The app list shows launcher-visible applications. Critical system packages, this app itself, and Android Settings are excluded from the general app blocklist. Settings has a separate experimental best-effort option so the recovery and connectivity paths are not casually removed.

## Build using the GitHub website workflow

1. Upload `Protection-Companion-Stage1-Redesign.zip` to the root of the existing GitHub repository.
2. Replace `.github/workflows/build.yml` with the accompanying `build-stage1-from-zip.yml` file (rename it to `build.yml` in GitHub).
3. Open **Actions**, choose **Build Protection Companion App Lock Update**, and run or wait for the build.
4. Download the artifact `protection-companion-app-lock-update-apk`. It includes the APK and provenance/class-list files.

CI prints the commit SHA, extracted source tree, APK entry check, and DEX class list. The version name includes the source commit's short SHA.

## Package identity

Application ID: `app.focusguard` (preserved from the existing Phase B ZIP). Namespace: `app.phasea.logger` (preserved to match the Java sources). A fresh GitHub-hosted runner may use a different debug signing key. If Android reports a signing conflict, do not uninstall the current app immediately: that deletes the local blocklist and settings. Report the exact error first so signing continuity can be resolved.


## Final requested additions

- Optional app-local 6–12 digit PIN gate, triggered when returning after the app has left the foreground. PINs are stored as salted PBKDF2-HMAC-SHA256 hashes; the raw PIN is not stored or logged. Forgotten-PIN recovery uses Android's secure device credential.
- Uninstall protection remains a Device Owner-only system policy. The app does not silently enroll the phone or imply the policy is active on a normal installation.
- No extra system restrictions are applied by this update.
