# Build and install — Protection Companion Stage 1

This ZIP is designed for the existing GitHub-web/GitHub-Actions workflow. No local Git clone or Termux is assumed.

## Source and toolchain

| Item | Value |
|---|---|
| Package ID | `app.focusguard` |
| Namespace | `app.phasea.logger` |
| Android min / target / compile SDK | 30 / 33 / 34 |
| JDK | 17 (Temurin) |
| Gradle | 8.7 |
| Android Gradle Plugin | 8.5.2 |
| Version | `0.3.0-alpha02-<short-source-sha>` |

## GitHub build

Upload `Protection-Companion-Stage1-Redesign.zip` at the repository root and replace `.github/workflows/build.yml` with the provided `build-stage1-from-zip.yml` contents. The workflow extracts the project into a clean build directory, validates the expected source tree, prints the repository commit SHA, builds `assembleDebug`, verifies the APK ZIP structure and expected class names, and uploads APK/provenance files.

Build command in CI:

```sh
gradle --no-daemon -PsourceRevision="$GITHUB_SHA" assembleDebug
```

APK path inside the extracted source project: `app/build/outputs/apk/debug/app-debug.apk`.

## Installation notes

The ordinary APK is intended to install through Android's package installer. If Android reports a signing conflict, do not uninstall the currently working APK immediately. Uninstalling erases the saved blocklist, appearance, and diagnostics. Stop and report the exact installer error so we can resolve signing continuity before replacing the working installation.

## Enforcement states

- **Best-effort:** Accessibility fallback sends Home after a selected app has started. It can be bypassed and may show the app briefly.
- **Device Owner:** only shown as active when Android reports this app is the Device Owner. No enrollment is performed by this build.
- **Uninstall protection:** not active on an ordinary installation. It can only be applied after the app has the required Device Owner authority.

Do not run Device Owner provisioning or activate system policies until the separate recovery procedure has been reviewed and rehearsed. This update adds an app PIN gate and clearer uninstall-policy status. It has not yet been built or tested on the target phone in this workspace; CI is the next compile/integration check.
