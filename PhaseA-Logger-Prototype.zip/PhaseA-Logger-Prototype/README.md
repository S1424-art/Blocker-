# Phase A Logger — observe-only prototype

This is a local diagnostic prototype, not a blocker or device-management app.

## Scope and data

- No `uses-permission` declarations and no Internet/network permission.
- No Device Owner provisioning, device-admin receiver, package suspension, uninstall prevention, or enforcement behavior.
- While the Accessibility service is enabled, it records foreground package/class metadata. For Android Settings (`com.android.settings`) and any package the user explicitly adds, it also records a bounded set of view resource IDs. The service code does **not** access or log AccessibilityEvent text, view text, content descriptions, or window titles. Marker notes are optional text you deliberately add inside this diagnostic app.
- Logs are stored in the app's private internal files area, capped at approximately 400 KB. The app has explicit controls to pause/resume, inspect, clear, and manually copy logs. Copying places data on the device clipboard; clipboard synchronization depends on the device's own settings, so review logs before sharing.
- Resource IDs and package/class names can still reveal which screens/apps were used. Enable the service only for a short, planned test and turn it off afterward.

## Toolchain

- Android Gradle Plugin (AGP): 8.5.2
- Gradle: 8.7
- JDK: 17
- Compile SDK: 34
- Minimum Android API: 26
- Target SDK: 33

AGP 8.5.x, Gradle 8.7, and JDK 17 are a compatible toolchain combination. The Gradle build uses the standard debug signing config; no custom keystore is included.

## Build locally

With JDK 17, Gradle 8.7, and Android SDK Platform 34 / Build Tools installed:

```sh
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build through GitHub Actions

Push this project to a private repository on the `main` branch, or manually run the `build-debug` workflow under **Actions**. The workflow installs JDK 17 and Gradle 8.7, runs `assembleDebug`, and uploads `phasea-debug-apk` as an artifact. The workflow does not need a repository secret for signing because it uses the regular debug signing configuration.

## Install and test on a test device

1. Install the debug APK on your own test device. Android may ask you to allow installs from the file manager/browser used to open it.
2. Open **Phase A Logger** and read its data-collection note.
3. Tap **Open Accessibility settings** and enable **Phase A Diagnostic Logger** only when you are ready to test. Android will show its Accessibility disclosure; review it before enabling.
4. Reproduce a small, predefined sequence of Settings screens and apps. Add extra package names only when structural resource IDs from those apps are needed.
5. Return to the app, refresh the local log, and record which screens/events appear. Do not share logs without reviewing them.
6. Pause logging and disable the Accessibility service in Android Settings when testing is complete. Clear the log if it is no longer needed.
7. Uninstall through Android's normal App info screen. This prototype contains no uninstall-prevention mechanism.

## Verification limits

A source/configuration inspection is not the same as a successful Android compilation or on-device test. The provided environment used to assemble this ZIP did not have Gradle or the Android SDK installed, and its network access could not resolve the Gradle/Android download hosts. Therefore, no actual APK build is claimed. The GitHub Actions workflow is included to perform the real build in an environment with network access; its result must be checked before installation.
