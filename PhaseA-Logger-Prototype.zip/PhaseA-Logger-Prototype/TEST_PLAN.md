# Phase A test plan and acceptance criteria

This plan is for the first manual test on the owner's Android device. Do not use a primary device containing sensitive information if a spare test device is available. Enable Accessibility only for the planned test window.

## Scope

Phase A observes selected UI metadata; it does not block, suspend, uninstall, force-stop, or restrict any app. It does not provision Device Owner or change device policy. Testing this build cannot establish that a future enforcement design would work.

## Test cases

| ID | Test | Expected result | Result |
|---|---|---|---|
| T01 | Install and launch debug APK | Main screen opens; no onboarding for device-admin/Device Owner appears | Pending on device |
| T02 | Review Android App info permissions | No ordinary runtime permission is requested; verify manifest has no `uses-permission` entries | Pending on device |
| T03 | Enable Phase A Diagnostic Logger manually | Android Accessibility settings show the service and Android's disclosure; service begins only after explicit enablement | Pending on device |
| T04 | Open several Settings screens | Log records package/class events and bounded view resource IDs; no screen text or window title is logged | Pending on device |
| T05 | Open another ordinary app | Log can record package/class metadata only; no view-tree snapshot unless that package was explicitly added | Pending on device |
| T06 | Add one test package and revisit it | Resource IDs may be recorded; text/content descriptions/window titles are not recorded | Pending on device |
| T07 | Pause logging, switch screens, refresh | No new navigation entries are added while paused; the explicit pause marker may appear | Pending on device |
| T08 | Resume logging and switch screens | New metadata events appear again | Pending on device |
| T09 | Clear log | Local diagnostic file becomes empty or nearly empty after subsequent app/service events | Pending on device |
| T10 | Copy log | Copy occurs only after the user taps Copy; review before sharing because clipboard sync may be enabled | Pending on device |
| T11 | Disable Accessibility service | Collection stops; the app remains installed and usable | Pending on device |
| T12 | Uninstall through Android App info | Standard uninstall succeeds; no uninstall-prevention behavior is present | Pending on device |

## Pass/fail rules

- **Pass for Phase A only** when T01–T12 produce their expected outcomes and the log contains no text, content descriptions, or window titles.
- **Stop immediately** if any text from another app appears in the log, the app requests unexpected permissions, or the app attempts to block/launch-control another app, modify device policies, or prevent ordinary uninstall.
- Collect only a short test log. Before sharing it for review, remove account names, identifiers, personal package names, or other information you do not want to disclose.

## Automated checks

Run `bash scripts/verify_phase_a.sh` in the project root. The workflow runs it before attempting the Android build. Passing static checks is necessary but not sufficient: it does not equal a successful APK build or an on-device test.
