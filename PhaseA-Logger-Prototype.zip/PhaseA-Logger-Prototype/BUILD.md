# Build and verify Phase A Logger

This is an observe-only Accessibility prototype. It is not a blocker and must not be used to enforce device policy.

## Exact build toolchain

- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- Android SDK Platform 34

## Local build

Run from the project root in an Android build environment:

```sh
gradle --no-daemon assembleDebug
```

Expected output path: `app/build/outputs/apk/debug/app-debug.apk`.

## CI build

The workflow is `.github/workflows/build.yml`. On a push to `main` or a manual `workflow_dispatch`, it installs the specified JDK/Gradle, verifies selected source constraints, runs the build, and uploads `phasea-debug-apk`. Inspect the actual job result and artifact before installing anything.

## Static checks

```sh
# No network permission or explicit app permissions:
grep -Rni 'uses-permission\|INTERNET' app/src/main || true

# No obvious enforcement/device-policy implementation:
grep -RniE 'DevicePolicyManager|setPackagesSuspended|setUninstallBlocked|performGlobalAction|DEVICE_ADMIN_ENABLED' app/src || true

# AccessibilityEvent text is never read by LoggerService:
grep -n 'getText()\|joinText' app/src/main/java/app/phasea/logger/LoggerService.java || true
```

Note: static checks cannot prove runtime behavior or replace an actual successful Gradle build and a test on the target phone.

Run the static check before a manual test:

```sh
bash scripts/verify_phase_a.sh
```
