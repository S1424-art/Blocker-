#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

required=(
  .github/workflows/build.yml
  .gitignore BUILD.md README.md TEST_PLAN.md VERIFICATION_REPORT.md
  scripts/verify_phase_a.sh
  build.gradle settings.gradle gradle.properties
  app/build.gradle
  app/src/main/AndroidManifest.xml
  app/src/main/java/app/phasea/logger/MainActivity.java
  app/src/main/java/app/phasea/logger/LoggerService.java
  app/src/main/java/app/phasea/logger/LogStore.java
  app/src/main/res/xml/accessibility_service_config.xml
  app/src/main/res/values/strings.xml
)
for f in "${required[@]}"; do
  [[ -f "$f" ]] || fail "Missing required file: $f"
done
pass "Required project files exist"

[[ ! -e debug.keystore ]] || fail "Custom debug.keystore must not be included"
if find . -type f \( -name '*.jks' -o -name '*.keystore' \) -not -path './.git/*' | grep -q .; then
  fail "Signing material found in project tree"
fi
pass "No custom signing key is included"

if grep -niE '<uses-permission([[:space:]>]|$)' app/src/main/AndroidManifest.xml; then
  fail "Manifest declares a uses-permission entry; Phase A is expected to declare none"
fi
if grep -RniE 'android\.permission\.INTERNET|uses-permission.*INTERNET' app/src; then
  fail "Network permission found"
fi
pass "Manifest declares no uses-permission entries or network permission"

if grep -RniE 'DevicePolicyManager|DeviceAdminReceiver|DEVICE_ADMIN_ENABLED|setPackagesSuspended|setUninstallBlocked|performGlobalAction|ACTION_DELETE' app/src; then
  fail "Potential enforcement / device-policy behavior found"
fi
pass "No known device-policy or blocking implementation patterns found"

service='app/src/main/java/app/phasea/logger/LoggerService.java'
if grep -nE '\.getText\s*\(|joinText\s*\(|getContentDescription\s*\(|getTitle\s*\(' "$service"; then
  fail "Screen text, content-description, window-title, or joinText access found in LoggerService"
fi
pass "LoggerService does not access screen text, content descriptions, window titles, or joinText"

if ! grep -q "version '8.5.2' apply false" build.gradle; then fail "Expected AGP 8.5.2 root declaration not found"; fi
if ! grep -q "gradle-version: '8.7'" .github/workflows/build.yml; then fail "Expected Gradle 8.7 CI configuration not found"; fi
if ! grep -q "java-version: '17'" .github/workflows/build.yml; then fail "Expected JDK 17 CI configuration not found"; fi
if ! grep -q 'gradle --no-daemon assembleDebug' .github/workflows/build.yml; then fail "CI build command missing"; fi
if ! grep -q 'app/build/outputs/apk/debug/app-debug.apk' .github/workflows/build.yml; then fail "Expected APK artifact path missing"; fi
pass "AGP / Gradle / JDK pins and APK artifact path are consistent"

python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path
files = sorted(Path('app/src/main').rglob('*.xml'))
if not files:
    raise SystemExit('No XML resources found')
for path in files:
    ET.parse(path)
    print(f'PASS: XML parses: {path}')
PY

pass "Phase A static verification complete"
echo "NOTE: This script does not compile Java, build an APK, or prove runtime behavior."
