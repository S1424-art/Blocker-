package app.phasea.logger;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayDeque;
import java.util.Locale;
import java.util.Set;

/**
 * Accessibility fallback for selected-app blocking. It reacts after a window appears, so it is
 * deliberately labelled best-effort. Strong suspension is handled separately by Device Owner.
 */
public class LoggerService extends AccessibilityService {
    private static final String SETTINGS_PKG = "com.android.settings";
    private static final int MAX_ACTIONS_PER_MINUTE = 30;
    private static final long ACTION_WINDOW_MS = 60_000L;
    private static final long DUPLICATE_GUARD_MS = 1_400L;
    private static final int MAX_SCAN_NODES = 140;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Long> recentActions = new ArrayDeque<>();
    private String lastRedirectPackage = "";
    private long lastRedirectAt;
    private long lastSettingsRedirectAt;
    private String lastWindowLine = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        LogStore.log(this, "SERVICE connected");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        String packageName = text(event.getPackageName());
        String className = text(event.getClassName());
        if (packageName.isEmpty() || packageName.equals(getPackageName())) return;

        if (!packageName.equals(lastRedirectPackage)) lastRedirectPackage = "";

        if (LogStore.isEnabled(this)) {
            String line = "WSC pkg=" + packageName + " cls=" + className;
            if (!line.equals(lastWindowLine)) {
                lastWindowLine = line;
                LogStore.append(this, line);
            }
        }

        if (SETTINGS_PKG.equals(packageName)) {
            if (Config.isSettingsGuardEnabled(this)) {
                handler.postDelayed(() -> evaluateSettingsWindow(className), 220L);
            }
            return;
        }

        if (!Config.isBlockingEnabled(this) || Config.isFallbackPaused(this)) return;
        if (!Config.blockedPackages(this).contains(packageName)) return;
        if (BlockerSafety.isNeverBlock(packageName, getPackageName())) return;
        if (Config.isSystemEnforcementEnabled(this) && DevicePolicyController.isPackageSuspended(this, packageName)) {
            return; // Android is already enforcing the suspension for this package.
        }
        redirectHome(packageName, false);
    }

    @Override
    public void onInterrupt() {
        LogStore.log(this, "SERVICE interrupted");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        LogStore.log(this, "SERVICE unbound");
        return super.onUnbind(intent);
    }

    private void evaluateSettingsWindow(String eventClass) {
        if (!Config.isSettingsGuardEnabled(this)) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            String activePackage = text(root.getPackageName());
            if (!SETTINGS_PKG.equals(activePackage)) return;
            String currentClass = eventClass.toLowerCase(Locale.ROOT);
            if (isEssentialSettingsClass(currentClass)) return;
            if (containsLabel(root, getString(R.string.app_name), new int[]{MAX_SCAN_NODES}, 0)) return;
            if (isConnectivityPage(root)) return;
            long now = android.os.SystemClock.elapsedRealtime();
            if (now - lastSettingsRedirectAt < DUPLICATE_GUARD_MS) return;
            lastSettingsRedirectAt = now;
            redirectHome(SETTINGS_PKG, true);
        } finally {
            root.recycle();
        }
    }

    /** Allowlist is conservative; Samsung's shared SubSettings screen means this is not exact. */
    private boolean isEssentialSettingsClass(String className) {
        String[] allowed = {
                "wifi", "internet", "bluetooth", "connecteddevices", "pairnewdevice", "mobilenetwork",
                "networkoperator", "tether", "simmanager",
                "developmentsettings", "deviceadminsettings"
        };
        for (String token : allowed) if (className.contains(token)) return true;
        return false;
    }

    /** Read page text only in memory to preserve connectivity routes; never log it. */
    private boolean isConnectivityPage(AccessibilityNodeInfo root) {
        String[] allowed = {
                "wi-fi", "wifi", "internet", "mobile networks", "mobile data", "network operator",
                "hotspot", "tethering", "bluetooth", "connected devices", "pair new device",
                "nearby devices", "sim manager", "connections", "الاتصالات", "الواي فاي",
                "واي فاي", "الإنترنت", "بيانات الهاتف", "شبكات المحمول", "نقطة اتصال", "مدير sim",
                "البلوتوث", "أجهزة متصلة", "الاجهزة المتصلة", "إقران جهاز جديد", "اقران جهاز جديد",
                "الأجهزة القريبة", "الاجهزة القريبة"
        };
        int[] budget = {MAX_SCAN_NODES};
        return containsAllowedLabel(root, allowed, budget, 0);
    }

    private boolean containsLabel(AccessibilityNodeInfo node, String expected, int[] budget, int depth) {
        if (node == null || budget[0] <= 0 || depth > 12) return false;
        budget[0]--;
        if (expected.equalsIgnoreCase(text(node.getText()).trim())
                || expected.equalsIgnoreCase(text(node.getContentDescription()).trim())) return true;
        int count = node.getChildCount();
        for (int i = 0; i < count && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = containsLabel(child, expected, budget, depth + 1);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private boolean containsAllowedLabel(AccessibilityNodeInfo node, String[] allowed,
                                         int[] budget, int depth) {
        if (node == null || budget[0] <= 0 || depth > 12) return false;
        budget[0]--;
        if (matchesAny(text(node.getText()), allowed)
                || matchesAny(text(node.getContentDescription()), allowed)) return true;
        int count = node.getChildCount();
        for (int i = 0; i < count && budget[0] > 0; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = containsAllowedLabel(child, allowed, budget, depth + 1);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private boolean matchesAny(String value, String[] allowed) {
        String normalized = value.toLowerCase(Locale.ROOT).trim();
        if (normalized.isEmpty() || normalized.length() > 180) return false;
        for (String term : allowed) {
            if (normalized.equals(term) || normalized.contains(term)) return true;
        }
        return false;
    }

    private void redirectHome(String packageName, boolean settingsRedirect) {
        long now = android.os.SystemClock.elapsedRealtime();
        if (!settingsRedirect && packageName.equals(lastRedirectPackage)
                && now - lastRedirectAt < DUPLICATE_GUARD_MS) return;
        while (!recentActions.isEmpty() && now - recentActions.peekFirst() > ACTION_WINDOW_MS) {
            recentActions.removeFirst();
        }
        if (recentActions.size() >= MAX_ACTIONS_PER_MINUTE) {
            Config.setFallbackPaused(this, true);
            Config.setSettingsGuardEnabled(this, false);
            LogStore.log(this, "SAFETY breaker reached; best-effort redirect paused");
            Toast.makeText(this, "Protection Companion paused its Accessibility fallback for safety. Turn blocking off and on to resume.",
                    Toast.LENGTH_LONG).show();
            recentActions.clear();
            return;
        }
        recentActions.addLast(now);
        boolean success = performGlobalAction(GLOBAL_ACTION_HOME);
        if (!settingsRedirect) {
            lastRedirectPackage = packageName;
            lastRedirectAt = now;
        }
        LogStore.log(this, (settingsRedirect ? "SETTINGS_GUARD" : "BLOCK_FALLBACK")
                + " home=" + success + " pkg=" + packageName);
    }

    private static String text(CharSequence value) {
        return value == null ? "" : value.toString();
    }
}
