package app.phasea.logger;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Read-back and explicitly requested system-policy operations. This class never provisions
 * Device Owner and never changes policy at application startup.
 */
final class DevicePolicyController {
    static final class Result {
        final boolean ok;
        final String message;

        Result(boolean ok, String message) {
            this.ok = ok;
            this.message = message;
        }
    }

    private DevicePolicyController() {}

    private static DevicePolicyManager manager(Context c) {
        return (DevicePolicyManager) c.getSystemService(Context.DEVICE_POLICY_SERVICE);
    }

    private static ComponentName admin(Context c) {
        return new ComponentName(c, ProtectionDeviceAdminReceiver.class);
    }

    static boolean isDeviceOwner(Context c) {
        DevicePolicyManager dpm = manager(c);
        return dpm != null && dpm.isDeviceOwnerApp(c.getPackageName());
    }

    static boolean isUninstallBlocked(Context c) {
        DevicePolicyManager dpm = manager(c);
        return isDeviceOwner(c) && dpm != null
                && dpm.isUninstallBlocked(admin(c), c.getPackageName());
    }

    /** Read back whether Android disables Force stop and Clear data for this app. */
    static boolean isForceStopProtectionActive(Context c) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || !isDeviceOwner(c)) return false;
        DevicePolicyManager dpm = manager(c);
        if (dpm == null) return false;
        try {
            List<String> packages = dpm.getUserControlDisabledPackages(admin(c));
            return packages != null && packages.contains(c.getPackageName());
        } catch (SecurityException | UnsupportedOperationException e) {
            LogStore.log(c, "POLICY user_control read error=" + e.getClass().getSimpleName());
            return false;
        }
    }

    static boolean isPackageSuspended(Context c, String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        try {
            return c.getPackageManager().isPackageSuspended(packageName);
        } catch (PackageManager.NameNotFoundException | SecurityException e) {
            return false;
        }
    }

    static Result setUninstallProtection(Context c, boolean enabled) {
        if (!isDeviceOwner(c)) {
            return new Result(false, "Device Owner is not active. No uninstall policy was changed.");
        }
        try {
            DevicePolicyManager dpm = manager(c);
            dpm.setUninstallBlocked(admin(c), c.getPackageName(), enabled);
            boolean actual = dpm.isUninstallBlocked(admin(c), c.getPackageName());
            LogStore.log(c, "POLICY uninstall_block requested=" + enabled + " readback=" + actual);
            return new Result(actual == enabled, actual == enabled
                    ? (enabled ? "Uninstall protection is active." : "Uninstall protection is off.")
                    : "The system read-back does not match the requested state.");
        } catch (SecurityException | IllegalArgumentException e) {
            LogStore.log(c, "POLICY uninstall_block error=" + e.getClass().getSimpleName());
            return new Result(false, "Android refused this policy: " + e.getClass().getSimpleName());
        }
    }

    /**
     * Disables Android's user controls only for Protection Companion itself.
     * Requires Device Owner; this app checks Device Owner status before changing this policy.
     */
    static Result setForceStopProtection(Context c, boolean enabled) {
        if (!isDeviceOwner(c)) {
            return new Result(false, "Device Owner is not active. Force-stop protection was not changed.");
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            return new Result(false, "Android 11 or newer is required for this policy.");
        }
        DevicePolicyManager dpm = manager(c);
        if (dpm == null) {
            return new Result(false, "Android DevicePolicyManager is unavailable.");
        }
        try {
            List<String> packages = new ArrayList<>(dpm.getUserControlDisabledPackages(admin(c)));
            String ownPackage = c.getPackageName();
            boolean wasBlocked = packages.contains(ownPackage);
            if (enabled && !wasBlocked) packages.add(ownPackage);
            if (!enabled && wasBlocked) packages.removeIf(ownPackage::equals);
            if (wasBlocked != enabled) {
                dpm.setUserControlDisabledPackages(admin(c), packages);
            }
            List<String> actualPackages = dpm.getUserControlDisabledPackages(admin(c));
            boolean actual = actualPackages != null && actualPackages.contains(ownPackage);
            LogStore.log(c, "POLICY user_control requested=" + enabled + " readback=" + actual);
            return new Result(actual == enabled, actual == enabled
                    ? (enabled ? "Android disabled Force stop and Clear data for Protection Companion." : "Force-stop and Clear data protection is off.")
                    : "Android's read-back does not match the requested force-stop policy.");
        } catch (SecurityException | IllegalArgumentException | UnsupportedOperationException e) {
            LogStore.log(c, "POLICY user_control error=" + e.getClass().getSimpleName());
            return new Result(false, "Android refused force-stop protection: " + e.getClass().getSimpleName());
        }
    }

    /** Synchronizes only packages owned by this app's own ledger; never suspends Settings or self. */
    static Result syncSuspensions(Context c, boolean enabled) {
        if (!isDeviceOwner(c)) {
            return new Result(false, "Device Owner is not active. No apps were suspended.");
        }
        DevicePolicyManager dpm = manager(c);
        if (dpm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return new Result(false, "This Android version does not support package suspension.");
        }

        Set<String> previouslyManaged = Config.managedPackages(c);
        Set<String> desired = new HashSet<>();
        if (enabled) {
            for (String pkg : Config.blockedPackages(c)) {
                if (!BlockerSafety.isNeverBlock(pkg, c.getPackageName())
                        && !BlockerSafety.isSettingsPackage(pkg)) desired.add(pkg);
            }
        }

        Set<String> toUnsuspend = new HashSet<>(previouslyManaged);
        toUnsuspend.removeAll(desired);
        List<String> failures = new ArrayList<>();
        Set<String> currentManaged = new HashSet<>(previouslyManaged);

        if (!toUnsuspend.isEmpty()) {
            try {
                String[] failed = dpm.setPackagesSuspended(admin(c), toUnsuspend.toArray(new String[0]), false);
                Set<String> failedSet = failed == null ? new HashSet<>() : new HashSet<>(Arrays.asList(failed));
                failures.addAll(failedSet);
                currentManaged.removeAll(toUnsuspend);
                currentManaged.addAll(failedSet);
            } catch (SecurityException | IllegalArgumentException e) {
                failures.addAll(toUnsuspend);
                LogStore.log(c, "POLICY unsuspend error=" + e.getClass().getSimpleName());
            }
        }

        Set<String> toSuspend = new HashSet<>(desired); // re-apply and verify even previously managed packages
        if (!toSuspend.isEmpty()) {
            try {
                String[] failed = dpm.setPackagesSuspended(admin(c), toSuspend.toArray(new String[0]), true);
                Set<String> failedSet = failed == null ? new HashSet<>() : new HashSet<>(Arrays.asList(failed));
                failures.addAll(failedSet);
                currentManaged.addAll(toSuspend);
                currentManaged.removeAll(failedSet);
            } catch (SecurityException | IllegalArgumentException e) {
                failures.addAll(toSuspend);
                LogStore.log(c, "POLICY suspend error=" + e.getClass().getSimpleName());
            }
        }

        Config.setManagedPackages(c, currentManaged);
        LogStore.log(c, "POLICY suspension enabled=" + enabled + " desired=" + desired.size()
                + " managed=" + currentManaged.size() + " failed=" + failures.size());
        if (failures.isEmpty()) {
            return new Result(true, enabled
                    ? "Android accepted the selected-app suspension policy. Verify each app below."
                    : "Managed app suspensions have been released where Android accepted the request.");
        }
        return new Result(false, "Partial result: " + failures.size()
                + " package(s) were not changed. Managed count: " + currentManaged.size() + ".");
    }

    static boolean areAllSelectedAppsSuspended(Context c) {
        if (!isDeviceOwner(c) || !Config.isSystemEnforcementEnabled(c)) return false;
        Set<String> desired = new HashSet<>();
        for (String pkg : Config.blockedPackages(c)) {
            if (!BlockerSafety.isNeverBlock(pkg, c.getPackageName())
                    && !BlockerSafety.isSettingsPackage(pkg)) desired.add(pkg);
        }
        if (desired.isEmpty()) return false;
        for (String pkg : desired) if (!isPackageSuspended(c, pkg)) return false;
        return true;
    }

    static int suspendedManagedCount(Context c) {
        int count = 0;
        for (String pkg : Config.managedPackages(c)) {
            if (isPackageSuspended(c, pkg)) count++;
        }
        return count;
    }

    static Result releaseAppPolicies(Context c) {
        if (!isDeviceOwner(c)) {
            return new Result(false, "Device Owner is not active. No system policies were changed.");
        }
        Result suspension = syncSuspensions(c, false);
        Result uninstall = setUninstallProtection(c, false);
        Result forceStop = setForceStopProtection(c, false);
        // Keep the local state marked active if read-back says some managed suspension remains.
        if (suspension.ok) {
            Config.setSystemEnforcementEnabled(c, false);
            Config.setBlockingEnabled(c, false);
        }
        Config.setSettingsGuardEnabled(c, false);
        boolean ok = suspension.ok && uninstall.ok && forceStop.ok;
        return new Result(ok, "App policies release attempted. " + suspension.message + " "
                + uninstall.message + " " + forceStop.message
                + " Device Owner enrollment itself is not removed by this action.");
    }
}
