package app.phasea.logger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Appearance, permission status, optional Settings screen gating, and explicit policy controls. */
public class SettingsActivity extends Activity {
    private TextView accessibilityValue;
    private TextView ownerValue;
    private TextView uninstallValue;
    private TextView systemPolicyValue;
    private Switch settingsGuardSwitch;
    private Switch systemPolicySwitch;
    private Switch uninstallSwitch;
    private LinearLayout deviceOwnerSection;
    private boolean updating;

    @Override
    protected void onCreate(Bundle state) {
        Ui.prepareTheme(this);
        super.onCreate(state);
        Ui.applyWindowColors(this);

        LinearLayout content = Ui.column(this);
        content.addView(Ui.title(this, "Settings"));
        content.addView(Ui.subtitle(this, "Appearance, permissions, and protection status."));

        LinearLayout appearance = Ui.card(this);
        appearance.addView(Ui.text(this, "Appearance", 17, true, R.color.pc_text));
        appearance.addView(Ui.text(this, "Choose the theme used inside Protection Companion.",
                13, false, R.color.pc_muted));
        RadioGroup themes = new RadioGroup(this);
        themes.setOrientation(RadioGroup.HORIZONTAL);
        themes.setGravity(Gravity.CENTER_VERTICAL);
        addThemeOption(themes, "System", Config.Appearance.SYSTEM);
        addThemeOption(themes, "Light", Config.Appearance.LIGHT);
        addThemeOption(themes, "Dark", Config.Appearance.DARK);
        appearance.addView(themes);
        content.addView(appearance);

        LinearLayout access = Ui.card(this);
        access.addView(Ui.text(this, "Required access", 17, true, R.color.pc_text));
        access.addView(Ui.text(this,
                "Accessibility is used only for the best-effort fallback. Android does not give this ordinary app uninstall protection through Accessibility.",
                13, false, R.color.pc_muted));
        accessibilityValue = Ui.valueRow(this, access, "Accessibility service");
        access.addView(actionButton("Open Accessibility settings", Ui.SECONDARY,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        content.addView(access);

        LinearLayout settingsCard = Ui.card(this);
        settingsCard.addView(Ui.text(this, "Settings app protection", 17, true, R.color.pc_text));
        settingsCard.addView(Ui.text(this,
                "Experimental, best-effort screen gating only. Samsung reuses Settings screens, so the connectivity and recovery exceptions are not guaranteed. Leave this off unless you have tested Wi‑Fi, mobile data, and Accessibility settings on this phone.",
                13, false, R.color.pc_muted));
        settingsGuardSwitch = new Switch(this);
        settingsGuardSwitch.setText("Protect most Settings screens");
        settingsGuardSwitch.setTextColor(Ui.color(this, R.color.pc_text));
        settingsGuardSwitch.setOnCheckedChangeListener((button, checked) -> onSettingsGuardChanged(checked));
        settingsCard.addView(settingsGuardSwitch);
        settingsCard.addView(actionButton("Open Internet / connectivity panel", Ui.SECONDARY,
                v -> startActivity(new Intent(this, ConnectivityActivity.class))));
        content.addView(settingsCard);

        deviceOwnerSection = Ui.column(this);
        LinearLayout ownerCard = Ui.card(this);
        ownerCard.addView(Ui.text(this, "System-level protection", 17, true, R.color.pc_text));
        ownerCard.addView(Ui.text(this,
                "Strong app suspension and uninstall prevention require Device Owner enrollment. This app does not enroll itself, and these policies are not applied automatically.",
                13, false, R.color.pc_muted));
        ownerValue = Ui.valueRow(this, ownerCard, "Device Owner");
        systemPolicyValue = Ui.valueRow(this, ownerCard, "App suspension");
        uninstallValue = Ui.valueRow(this, ownerCard, "Uninstall protection");
        deviceOwnerSection.addView(ownerCard);

        LinearLayout controls = Ui.card(this);
        controls.addView(Ui.text(this, "Available only when Device Owner is active", 15, true, R.color.pc_text));
        systemPolicySwitch = new Switch(this);
        systemPolicySwitch.setText("Enforce blocklist in Android");
        systemPolicySwitch.setTextColor(Ui.color(this, R.color.pc_text));
        systemPolicySwitch.setOnCheckedChangeListener((button, checked) -> onSystemPolicyChanged(checked));
        controls.addView(systemPolicySwitch);
        uninstallSwitch = new Switch(this);
        uninstallSwitch.setText("Prevent uninstall of this app");
        uninstallSwitch.setTextColor(Ui.color(this, R.color.pc_text));
        uninstallSwitch.setOnCheckedChangeListener((button, checked) -> onUninstallProtectionChanged(checked));
        controls.addView(uninstallSwitch);
        controls.addView(actionButton("Release app-level policies", Ui.DANGER,
                v -> confirmReleasePolicies()));
        controls.addView(Ui.text(this,
                "Release app-level policies does not remove Device Owner enrollment. Keep ADB available during any future Device Owner test and review the recovery guide before provisioning.",
                12, false, R.color.pc_muted));
        deviceOwnerSection.addView(controls);
        content.addView(deviceOwnerSection);

        LinearLayout support = Ui.card(this);
        support.addView(Ui.text(this, "Diagnostics and build", 17, true, R.color.pc_text));
        support.addView(Ui.text(this, "Logs are stored locally. Review them before sharing because package and activity names may appear.",
                13, false, R.color.pc_muted));
        support.addView(actionButton("Open diagnostics log", Ui.SECONDARY,
                v -> startActivity(new Intent(this, DiagnosticsActivity.class))));
        support.addView(Ui.text(this, "Version: " + BuildConfig.VERSION_NAME
                + "\nSource revision: " + shortRevision(BuildConfig.SOURCE_REVISION)
                + "\nNetwork permission: not requested", 12, false, R.color.pc_muted));
        content.addView(support);
        content.addView(actionButton("Back to app list", Ui.QUIET, v -> finish()));

        setContentView(Ui.page(this, content));
        refreshStatus();
    }

    private android.widget.Button actionButton(String label, int style, android.view.View.OnClickListener listener) {
        android.widget.Button button = Ui.button(this, label, style);
        button.setOnClickListener(listener);
        return button;
    }

    private void addThemeOption(RadioGroup group, String label, Config.Appearance appearance) {
        RadioButton option = new RadioButton(this);
        option.setText(label);
        option.setTextSize(13);
        option.setTextColor(Ui.color(this, R.color.pc_text));
        option.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.color(this, R.color.pc_primary)));
        option.setChecked(Config.appearance(this) == appearance);
        option.setOnClickListener(v -> {
            Config.setAppearance(this, appearance);
            recreate();
        });
        group.addView(option, new RadioGroup.LayoutParams(0, -2, 1f));
    }

    private void onSettingsGuardChanged(boolean checked) {
        if (updating) return;
        if (checked) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable experimental Settings protection?")
                    .setMessage("Some Settings screens may be redirected to Home. The connectivity exception is best-effort on Samsung One UI. Accessibility settings and several recovery screens are allowlisted, but no screen-level exception is guaranteed. You can return here to turn it off.")
                    .setPositiveButton("Enable", (d, w) -> {
                        Config.setSettingsGuardEnabled(this, true);
                        refreshStatus();
                    })
                    .setNegativeButton("Cancel", (d, w) -> refreshStatus())
                    .show();
        } else {
            Config.setSettingsGuardEnabled(this, false);
            refreshStatus();
        }
    }

    private void onSystemPolicyChanged(boolean checked) {
        if (updating) return;
        if (!DevicePolicyController.isDeviceOwner(this)) {
            Toast.makeText(this, "Device Owner is not active; nothing was changed.", Toast.LENGTH_LONG).show();
            refreshStatus();
            return;
        }
        if (checked && Config.blockedPackages(this).isEmpty()) {
            Toast.makeText(this, "Select at least one app first.", Toast.LENGTH_LONG).show();
            refreshStatus();
            return;
        }
        if (checked) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable Android app suspension?")
                    .setMessage("Android may prevent selected apps from launching until the blocklist is changed or this policy is released. Settings and essential system packages are excluded. The app will verify the system read-back and report packages it could not suspend. Continue only after reviewing the recovery guide.")
                    .setPositiveButton("Enable", (d, w) -> {
                        Config.setSystemEnforcementEnabled(this, true);
                        Config.setBlockingEnabled(this, true);
                        DevicePolicyController.Result result = DevicePolicyController.syncSuspensions(this, true);
                        Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                        refreshStatus();
                    })
                    .setNegativeButton("Cancel", (d, w) -> refreshStatus())
                    .show();
        } else {
            DevicePolicyController.Result result = DevicePolicyController.syncSuspensions(this, false);
            Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
            if (result.ok) {
                Config.setSystemEnforcementEnabled(this, false);
                Config.setBlockingEnabled(this, false);
            }
            refreshStatus();
        }
    }

    private void onUninstallProtectionChanged(boolean checked) {
        if (updating) return;
        if (!DevicePolicyController.isDeviceOwner(this)) {
            Toast.makeText(this, "Device Owner is not active; uninstall protection remains off.", Toast.LENGTH_LONG).show();
            refreshStatus();
            return;
        }
        if (checked) {
            new AlertDialog.Builder(this)
                    .setTitle("Prevent uninstall of Protection Companion?")
                    .setMessage("While enabled, Android Settings will refuse to uninstall this app. You can disable this switch here while the app remains usable. This does not protect against every recovery route and does not remove Device Owner enrollment. Proceed only after you have rehearsed the recovery steps.")
                    .setPositiveButton("Enable", (d, w) -> {
                        DevicePolicyController.Result result = DevicePolicyController.setUninstallProtection(this, true);
                        Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                        refreshStatus();
                    })
                    .setNegativeButton("Cancel", (d, w) -> refreshStatus())
                    .show();
        } else {
            DevicePolicyController.Result result = DevicePolicyController.setUninstallProtection(this, false);
            Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
            refreshStatus();
        }
    }

    private void confirmReleasePolicies() {
        if (!DevicePolicyController.isDeviceOwner(this)) {
            Toast.makeText(this, "Device Owner is not active; there are no app-level policies to release.", Toast.LENGTH_LONG).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Release active app policies?")
                .setMessage("This tries to unblock uninstall and unsuspend packages managed by this app. It does not remove Device Owner enrollment. Android read-back and diagnostics will show any remaining policy state.")
                .setPositiveButton("Release policies", (d, w) -> {
                    DevicePolicyController.Result result = DevicePolicyController.releaseAppPolicies(this);
                    Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
                    refreshStatus();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Ui.applyWindowColors(this);
        refreshStatus();
    }

    private void refreshStatus() {
        if (accessibilityValue == null) return;
        updating = true;
        boolean service = Config.isServiceEnabled(this);
        boolean owner = DevicePolicyController.isDeviceOwner(this);
        boolean uninstallBlocked = DevicePolicyController.isUninstallBlocked(this);
        boolean systemPolicy = Config.isSystemEnforcementEnabled(this) && Config.isBlockingEnabled(this) && owner;
        accessibilityValue.setText(service ? "Enabled" : "Not enabled");
        accessibilityValue.setTextColor(Ui.color(this, service ? R.color.pc_ok : R.color.pc_caution));
        ownerValue.setText(owner ? "Active" : "Not active");
        ownerValue.setTextColor(Ui.color(this, owner ? R.color.pc_ok : R.color.pc_caution));
        uninstallValue.setText(uninstallBlocked ? "Enforced" : (owner ? "Off" : "Requires Device Owner"));
        uninstallValue.setTextColor(Ui.color(this, uninstallBlocked ? R.color.pc_ok : R.color.pc_muted));
        int selectedCount = 0;
        for (String pkg : Config.blockedPackages(this)) {
            if (!BlockerSafety.isNeverBlock(pkg, getPackageName())
                    && !BlockerSafety.isSettingsPackage(pkg)) selectedCount++;
        }
        int suspendedCount = DevicePolicyController.suspendedManagedCount(this);
        systemPolicyValue.setText(systemPolicy
                ? (suspendedCount + " / " + selectedCount + " selected apps suspended (read-back)")
                : "Not active");
        boolean allSuspended = systemPolicy && selectedCount > 0 && suspendedCount == selectedCount;
        systemPolicyValue.setTextColor(Ui.color(this, allSuspended ? R.color.pc_ok
                : (systemPolicy ? R.color.pc_caution : R.color.pc_muted)));
        settingsGuardSwitch.setChecked(Config.isSettingsGuardEnabled(this));
        systemPolicySwitch.setChecked(systemPolicy);
        uninstallSwitch.setChecked(uninstallBlocked);
        systemPolicySwitch.setEnabled(owner);
        uninstallSwitch.setEnabled(owner);
        deviceOwnerSection.setVisibility(android.view.View.VISIBLE);
        updating = false;
    }

    private static String shortRevision(String revision) {
        if (revision == null || revision.trim().isEmpty()) return "unknown";
        return revision.length() <= 8 ? revision : revision.substring(0, 8);
    }
}
