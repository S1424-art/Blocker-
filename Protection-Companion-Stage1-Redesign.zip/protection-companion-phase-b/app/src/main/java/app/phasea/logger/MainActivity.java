package app.phasea.logger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Locale;

/** Home: select apps and control persistent blocking without a duration or ARM timer. */
public class MainActivity extends Activity {
    private static final class AppEntry {
        String packageName;
        String label;
        boolean system;
        Drawable icon;
    }

    private final List<AppEntry> allApps = new ArrayList<>();
    private LinearLayout appList;
    private EditText search;
    private TextView countText;
    private TextView statusTitle;
    private TextView statusBody;
    private TextView devicePolicyPill;
    private Switch blockingSwitch;
    private CheckBox includeSystem;
    private boolean rendering;

    @Override
    protected void onCreate(Bundle state) {
        Ui.prepareTheme(this);
        super.onCreate(state);
        Config.sanitizeBlocklist(this);
        Ui.applyWindowColors(this);
        buildLayout();
        loadApps();
    }

    private void buildLayout() {
        LinearLayout content = Ui.column(this);
        LinearLayout header = Ui.row(this);
        LinearLayout heading = Ui.column(this);
        heading.addView(Ui.title(this, getString(R.string.app_name)));
        heading.addView(Ui.subtitle(this, "Choose what stays blocked. Your list stays on this phone."));
        header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView settings = Ui.text(this, "⚙", 25, true, R.color.pc_primary);
        settings.setGravity(Gravity.CENTER);
        settings.setContentDescription("Settings");
        settings.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 12));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        header.addView(settings, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        content.addView(header);

        LinearLayout statusCard = Ui.card(this);
        LinearLayout statusRow = Ui.row(this);
        statusTitle = Ui.text(this, "Blocking is off", 17, true, R.color.pc_text);
        devicePolicyPill = Ui.pill(this, "NOT ACTIVE", R.color.pc_muted);
        statusRow.addView(statusTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        statusRow.addView(devicePolicyPill);
        statusCard.addView(statusRow);
        statusBody = Ui.text(this,
                "Select apps below. Nothing will be blocked until you enable it.",
                13, false, R.color.pc_muted);
        statusBody.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 8));
        statusCard.addView(statusBody);
        blockingSwitch = new Switch(this);
        blockingSwitch.setText("Enable blocking");
        blockingSwitch.setTextSize(15);
        blockingSwitch.setTextColor(Ui.color(this, R.color.pc_text));
        blockingSwitch.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        statusCard.addView(blockingSwitch);
        blockingSwitch.setOnCheckedChangeListener((button, checked) -> onBlockingChanged(checked));
        content.addView(statusCard);

        LinearLayout listHeading = Ui.row(this);
        TextView listTitle = Ui.text(this, "Apps", 19, true, R.color.pc_text);
        countText = Ui.text(this, "Loading…", 12, false, R.color.pc_muted);
        countText.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        listHeading.addView(listTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        listHeading.addView(countText);
        content.addView(listHeading);

        LinearLayout filters = Ui.card(this);
        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setHint("Search installed apps");
        search.setPadding(Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) { renderApps(); }
        });
        filters.addView(search);
        includeSystem = new CheckBox(this);
        includeSystem.setText("Include system apps");
        includeSystem.setTextColor(Ui.color(this, R.color.pc_text));
        includeSystem.setOnCheckedChangeListener((button, checked) -> renderApps());
        filters.addView(includeSystem);
        content.addView(filters);

        LinearLayout appCard = Ui.card(this);
        appList = Ui.column(this);
        appCard.addView(appList);
        content.addView(appCard);

        LinearLayout footer = Ui.column(this);
        footer.addView(Ui.text(this,
                "Accessibility blocking is a best-effort fallback: the selected app may appear briefly before Home is shown. It cannot itself prevent uninstall or stop the service being disabled.",
                12, false, R.color.pc_muted));
        Button openSettings = Ui.button(this, "Settings and protection status", Ui.SECONDARY);
        openSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        footer.addView(openSettings);
        Button diagnostics = Ui.button(this, "Diagnostics", Ui.QUIET);
        diagnostics.setOnClickListener(v -> startActivity(new Intent(this, DiagnosticsActivity.class)));
        footer.addView(diagnostics);
        content.addView(footer);
        setContentView(Ui.page(this, content));
    }

    private void onBlockingChanged(boolean checked) {
        if (rendering) return;
        if (checked && Config.blockedPackages(this).isEmpty()) {
            Toast.makeText(this, "Select at least one app first.", Toast.LENGTH_LONG).show();
            refreshStatus();
            return;
        }
        boolean systemReady = Config.isSystemEnforcementEnabled(this)
                && DevicePolicyController.isDeviceOwner(this);
        if (checked && !systemReady && !Config.isServiceEnabled(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Enable Accessibility first")
                    .setMessage("This installed build uses Accessibility as a best-effort fallback. Blocking will not run until the service is enabled in Android settings. Protection Companion does not open that settings screen directly. Device Owner enforcement is a separate setup and is not active on this phone.")
                    .setPositiveButton("OK", (d, w) -> { })
                    .setNegativeButton("Cancel", null)
                    .show();
            refreshStatus();
            return;
        }
        if (checked) {
            Config.setFallbackPaused(this, false);
            Config.setBlockingEnabled(this, true);
        } else if (Config.isSystemEnforcementEnabled(this) && DevicePolicyController.isDeviceOwner(this)) {
            // Do not present the master switch as OFF while Android still reports suspended apps.
            DevicePolicyController.Result result = DevicePolicyController.syncSuspensions(this, false);
            Toast.makeText(this, result.message, Toast.LENGTH_LONG).show();
            if (result.ok) {
                Config.setSystemEnforcementEnabled(this, false);
                Config.setBlockingEnabled(this, false);
                Config.setFallbackPaused(this, false);
            }
        } else {
            Config.setBlockingEnabled(this, false);
            Config.setFallbackPaused(this, false);
        }
        refreshStatus();
    }

    private void loadApps() {
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> resolved = pm.queryIntentActivities(launcher, 0);
            List<AppEntry> found = new ArrayList<>();
            Set<String> seenPackages = new HashSet<>();
            for (ResolveInfo info : resolved) {
                if (info.activityInfo == null) continue;
                String pkg = info.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || BlockerSafety.isSettingsPackage(pkg)
                        || BlockerSafety.isNeverBlock(pkg, getPackageName())
                        || !seenPackages.add(pkg)) continue;
                AppEntry entry = new AppEntry();
                entry.packageName = pkg;
                entry.label = String.valueOf(info.loadLabel(pm));
                entry.icon = info.loadIcon(pm);
                int flags = info.activityInfo.applicationInfo.flags;
                entry.system = (flags & ApplicationInfo.FLAG_SYSTEM) != 0
                        || (flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                found.add(entry);
            }
            Collections.sort(found, (a, b) -> a.label.compareToIgnoreCase(b.label));
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                allApps.clear();
                allApps.addAll(found);
                renderApps();
                refreshStatus();
            });
        }).start();
    }

    private void renderApps() {
        if (appList == null) return;
        String query = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        boolean showSystem = includeSystem != null && includeSystem.isChecked();
        appList.removeAllViews();
        int shown = 0;
        for (AppEntry entry : allApps) {
            if (entry.system && !showSystem) continue;
            if (!entry.label.toLowerCase(Locale.ROOT).contains(query)
                    && !entry.packageName.toLowerCase(Locale.ROOT).contains(query)) continue;
            if (shown > 0) {
                View divider = new View(this);
                divider.setBackgroundColor(Ui.color(this, R.color.pc_stroke));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 1));
                lp.setMargins(0, Ui.dp(this, 5), 0, Ui.dp(this, 5));
                appList.addView(divider, lp);
            }
            appList.addView(appRow(entry, Config.isProtected(this, entry.packageName)));
            shown++;
        }
        if (shown == 0) {
            TextView empty = Ui.text(this, "No matching apps found.", 14, false, R.color.pc_muted);
            appList.addView(empty);
        }
        int selected = Config.blockedPackages(this).size();
        countText.setText(selected + " blocked · " + shown + " shown");
    }

    private View appRow(AppEntry entry, boolean checked) {
        LinearLayout row = Ui.row(this);
        row.setPadding(0, Ui.dp(this, 7), 0, Ui.dp(this, 7));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(entry.icon);
        icon.setContentDescription(entry.label + " icon");
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42));
        iconLp.setMargins(0, 0, Ui.dp(this, 12), 0);
        row.addView(icon, iconLp);

        LinearLayout textCol = Ui.column(this);
        TextView name = Ui.text(this, entry.label, 15, true, R.color.pc_text);
        name.setMaxLines(2);
        TextView pkg = Ui.text(this, entry.packageName, 10, false, R.color.pc_muted);
        pkg.setMaxLines(1);
        pkg.setSingleLine(true);
        pkg.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textCol.addView(name);
        textCol.addView(pkg);
        row.addView(textCol, new LinearLayout.LayoutParams(0, -2, 1f));

        CheckBox check = new CheckBox(this);
        check.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.color(this, R.color.pc_primary)));
        check.setChecked(checked);
        check.setContentDescription("Block " + entry.label);
        check.setOnCheckedChangeListener((button, value) -> {
            DevicePolicyController.Result policyResult =
                    Config.setProtected(this, entry.packageName, entry.label, value);
            if (policyResult != null && !policyResult.ok) {
                Toast.makeText(this, policyResult.message, Toast.LENGTH_LONG).show();
            }
            renderApps();
            refreshStatus();
        });
        row.addView(check, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 48)));
        return row;
    }

    @Override
    protected void onResume() {
        super.onResume();
        Ui.applyWindowColors(this);
        refreshStatus();
        renderApps();
    }

    private void refreshStatus() {
        if (blockingSwitch == null) return;
        rendering = true;
        blockingSwitch.setChecked(Config.isBlockingEnabled(this));
        rendering = false;

        boolean owner = DevicePolicyController.isDeviceOwner(this);
        boolean systemPolicyRequested = owner && Config.isSystemEnforcementEnabled(this)
                && Config.isBlockingEnabled(this);
        boolean policyOn = owner && DevicePolicyController.areAllSelectedAppsSuspended(this);
        boolean fallbackOn = Config.isBlockingEnabled(this) && Config.isServiceEnabled(this)
                && !Config.isFallbackPaused(this);
        if (policyOn) {
            statusTitle.setText("System-level blocking enabled");
            devicePolicyPill.setText("DEVICE OWNER");
            devicePolicyPill.setTextColor(Ui.color(this, R.color.pc_ok));
            statusBody.setText("Android confirms that every selected app is suspended. Some critical system apps remain excluded.");
        } else if (systemPolicyRequested) {
            statusTitle.setText("System policy needs attention");
            devicePolicyPill.setText("PARTIAL POLICY");
            devicePolicyPill.setTextColor(Ui.color(this, R.color.pc_caution));
            statusBody.setText("Android does not confirm suspension of every selected app. Open Settings to inspect the read-back."
                    + (fallbackOn ? " The Accessibility fallback is also active." : ""));
        } else if (Config.isBlockingEnabled(this) && Config.isFallbackPaused(this)) {
            statusTitle.setText("Accessibility fallback paused for safety");
            devicePolicyPill.setText("SAFETY PAUSED");
            devicePolicyPill.setTextColor(Ui.color(this, R.color.pc_warn));
            statusBody.setText("Repeated redirects triggered the safety circuit breaker. Turn blocking off, review the cause, then turn it on to resume.");
        } else if (fallbackOn) {
            statusTitle.setText("Best-effort blocking is on");
            devicePolicyPill.setText("ACCESSIBILITY");
            devicePolicyPill.setTextColor(Ui.color(this, R.color.pc_caution));
            statusBody.setText("Selected apps are redirected to Home after launch. This is not OS-level suspension and can be bypassed.");
        } else if (Config.isBlockingEnabled(this)) {
            statusTitle.setText("Blocking needs attention");
            devicePolicyPill.setText("NOT ACTIVE");
            devicePolicyPill.setTextColor(Ui.color(this, R.color.pc_warn));
            statusBody.setText("Neither a confirmed Device Owner policy nor an active Accessibility fallback is ready.");
        } else {
            statusTitle.setText("Blocking is off");
            devicePolicyPill.setText(owner ? "DEVICE OWNER READY" : "NOT ACTIVE");
            devicePolicyPill.setTextColor(Ui.color(this, R.color.pc_muted));
            statusBody.setText("Choose apps below, then enable blocking. Your selection is saved on this phone.");
        }
    }
}
