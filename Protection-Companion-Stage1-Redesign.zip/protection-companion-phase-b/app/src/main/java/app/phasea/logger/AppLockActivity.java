package app.phasea.logger;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** App-local PIN gate. A matching PIN opens the app automatically; no reset shortcut is shown. */
public final class AppLockActivity extends Activity {
    private EditText pinInput;
    private TextView message;
    private String textBeforeChange = "";
    private boolean suppressEditAccounting;
    private boolean unlocking;

    @Override protected void onCreate(Bundle state) {
        Ui.prepareTheme(this);
        super.onCreate(state);
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE);
        Ui.applyWindowColors(this);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);

        LinearLayout content = Ui.column(this);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.addView(Ui.title(this, "Protection Companion"));
        content.addView(Ui.subtitle(this, "Enter your app PIN. A correct PIN opens the app automatically."));
        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, "App locked", 19, true, R.color.pc_text));
        card.addView(Ui.text(this,
                "This PIN protects access to the app's settings and blocklist. It is separate from Android's uninstall-protection policy.",
                13, false, R.color.pc_muted));
        pinInput = new EditText(this);
        pinInput.setSingleLine(true);
        pinInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(12)});
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setImeOptions(EditorInfo.IME_ACTION_DONE);
        pinInput.setHint("6–12 digit PIN");
        pinInput.setTextSize(20);
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setSelectAllOnFocus(true);
        pinInput.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        card.addView(pinInput);
        message = Ui.text(this, "", 13, false, R.color.pc_muted);
        message.setPadding(0, Ui.dp(this, 6), 0, 0);
        card.addView(message);
        content.addView(card);
        setContentView(Ui.page(this, content));

        pinInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                textBeforeChange = s == null ? "" : s.toString();
            }

            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override public void afterTextChanged(Editable editable) {
                String candidate = editable == null ? "" : editable.toString();
                if (suppressEditAccounting || unlocking) {
                    textBeforeChange = candidate;
                    suppressEditAccounting = false;
                    return;
                }

                // If the user replaces/clears a completed candidate rather than extending it,
                // count that prior candidate as one failed attempt. Extending a PIN prefix is free.
                String prior = textBeforeChange;
                boolean isExtension = !prior.isEmpty() && candidate.startsWith(prior);
                if (prior.length() >= 6 && !candidate.equals(prior) && !isExtension
                        && AppLockManager.shouldCountEditedCandidate(AppLockActivity.this, prior)) {
                    AppLockManager.VerifyResult failed = AppLockManager.recordFailedAttempt(AppLockActivity.this);
                    if (failed == AppLockManager.VerifyResult.TEMPORARILY_LOCKED) {
                        clearInputWithoutAccounting();
                        updateLockoutMessage();
                        return;
                    }
                }

                if (candidate.length() >= 6 && candidate.length() <= 12) {
                    AppLockManager.VerifyResult result = AppLockManager.verifyPinCandidate(
                            AppLockActivity.this, candidate);
                    if (result == AppLockManager.VerifyResult.SUCCESS) {
                        unlockAndFinish();
                        return;
                    }
                    if (result == AppLockManager.VerifyResult.TEMPORARILY_LOCKED) {
                        updateLockoutMessage();
                        textBeforeChange = candidate;
                        return;
                    }

                    // For new PINs, its length is known, so a wrong candidate at exactly that
                    // length is a complete attempt and gets counted immediately.
                    int expectedLength = AppLockManager.configuredPinLength(AppLockActivity.this);
                    if (expectedLength > 0 && candidate.length() == expectedLength) {
                        AppLockManager.VerifyResult counted = AppLockManager.recordFailedAttempt(
                                AppLockActivity.this);
                        clearInputWithoutAccounting();
                        if (counted == AppLockManager.VerifyResult.TEMPORARILY_LOCKED) {
                            updateLockoutMessage();
                        } else {
                            showIncorrectMessage();
                        }
                        return;
                    }
                }
                updateLockoutMessageIfNeeded();
                textBeforeChange = candidate;
            }
        });

        pinInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                submitCurrentCandidate();
                return true;
            }
            return false;
        });
        pinInput.requestFocus();
        updateLockoutMessage();
    }

    private void submitCurrentCandidate() {
        if (unlocking) return;
        if (AppLockManager.remainingLockoutMs(this) > 0) {
            updateLockoutMessage();
            return;
        }
        String pin = pinInput.getText() == null ? "" : pinInput.getText().toString();
        if (pin.length() < 6 || pin.length() > 12) {
            pinInput.setError("Enter your 6–12 digit PIN");
            return;
        }
        AppLockManager.VerifyResult result = AppLockManager.verifyPin(this, pin);
        if (result == AppLockManager.VerifyResult.SUCCESS) {
            unlockAndFinish();
        } else if (result == AppLockManager.VerifyResult.TEMPORARILY_LOCKED) {
            clearInputWithoutAccounting();
            updateLockoutMessage();
        } else {
            clearInputWithoutAccounting();
            showIncorrectMessage();
        }
    }

    private void showIncorrectMessage() {
        message.setText("Incorrect PIN. A correct PIN opens automatically as you type.");
        message.setTextColor(Ui.color(this, R.color.pc_warn));
    }

    private void updateLockoutMessageIfNeeded() {
        if (AppLockManager.remainingLockoutMs(this) > 0) updateLockoutMessage();
        else {
            message.setText("");
            message.setTextColor(Ui.color(this, R.color.pc_muted));
        }
    }

    private void updateLockoutMessage() {
        long remaining = AppLockManager.remainingLockoutMs(this);
        if (message == null) return;
        if (remaining > 0) {
            message.setText("Try again in " + Math.max(1L, (remaining + 999L) / 1000L) + " seconds.");
            message.setTextColor(Ui.color(this, R.color.pc_caution));
        } else {
            message.setText("");
            message.setTextColor(Ui.color(this, R.color.pc_muted));
        }
    }

    private void clearInputWithoutAccounting() {
        suppressEditAccounting = true;
        textBeforeChange = "";
        pinInput.setText("");
    }

    private void unlockAndFinish() {
        if (unlocking) return;
        unlocking = true;
        AppLockManager.unlockSession(this);
        Intent home = new Intent(this, MainActivity.class);
        home.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(home);
        finish();
    }

    @Override public void onBackPressed() {
        // Stay on the lock screen; Home is still available through Android system navigation.
    }
}
