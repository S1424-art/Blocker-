# Recovery guide — read before testing

This guide describes app-level recovery for the current development build. The ordinary install does not become Device Owner automatically.

## Ordinary installation (no Device Owner)

1. Open Protection Companion and turn **Enable blocking** off.
2. Open Settings and turn **Protect most Settings screens** off if it was enabled.
3. Open Android Accessibility settings and turn off the Protection Companion service.
4. Use Android Settings > Apps > Protection Companion > Uninstall if you want to remove it.

## If Device Owner is active in a future test build

- The in-app **Release app-level policies** action attempts to release package suspensions recorded in this app's ledger and turn off this app's uninstall block. It reads back/report results but does not remove Device Owner enrollment.
- Do not rely on `clearDeviceOwnerApp()` as a clean undo. Some policy state can remain.
- A `testOnly` test build is expected for a dedicated enrollment/recovery rehearsal. The ADB removal command and exact component/package must be confirmed for the actual test build before enrollment. Keep ADB available and rehearse the procedure before activating any policy.
- Do not disable debugging features or suspend Settings during an initial test.
- A hardware recovery/factory reset is a last-resort route and erases internal data. Verify account credentials and backups first.

## Never do this during initial testing

- Do not remove Google/Samsung accounts solely to attempt Device Owner enrollment without an independently reviewed plan and backup.
- Do not block Settings, the launcher, dialer, permission controller, keyboard, or package installer.
- Do not disable ADB debugging or add factory-reset restrictions.
- Do not call a policy “Enforced” unless Android read-back confirms it.

The current ZIP does not claim that a Device Owner removal procedure has been rehearsed on the Samsung A32 5G. Do not enroll the primary phone until that limitation is resolved.
