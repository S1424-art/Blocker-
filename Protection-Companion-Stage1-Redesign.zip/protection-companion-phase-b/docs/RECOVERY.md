# Recovery notes — Protection Companion

## App PIN lock

- The app PIN is local-only and is stored as a salted PBKDF2-HMAC-SHA256 hash. The raw PIN is never written to logs.
- The app gate opens automatically when the correct 6–12 digit PIN is entered. There is no in-app **Forgot PIN** or reset bypass.
- Keep the app PIN in a secure place before enabling the lock. The app PIN is separate from Android's screen lock; the phone screen lock does not recover or reset it.
- Five consecutive incorrect PIN attempts trigger a 30-second pause.
- The app PIN only gates this app's UI. It does not stop Android from uninstalling the app, clearing its data, force-stopping it, or disabling Accessibility.
- If the app PIN is forgotten, recovery may require a separate device/app recovery procedure. Do not enable the lock until you are confident you can retain the PIN; clearing app data or reinstalling may erase local configuration and is not a normal recovery path.

## Force-stop and clear-data protection

- The app uses `DevicePolicyManager.setUserControlDisabledPackages()` to ask Android to disable the **Force stop** and **Clear data** controls for Protection Companion itself. It never applies this policy to other packages.
- This policy is available only when Android reports Protection Companion as Device Owner; an ordinary APK and Accessibility service cannot enforce it. The UI reads the policy back from Android rather than trusting a switch state.
- The in-app **Release app-level policies** action attempts to remove this restriction and the uninstall-block policy while Protection Companion is running. It does not remove Device Owner enrollment. If the app is broken or cannot be opened, recovery may require the previously tested device-management recovery route.
- Do not enable this protection on a personal phone until a trusted adult has reviewed a practical recovery route. Device Owner provisioning and restrictive policies can make device recovery difficult.

## Uninstall protection

A normal app installation cannot enforce uninstall blocking. The app calls `DevicePolicyManager.setUninstallBlocked()` only when Android reports this package as Device Owner. Installing the APK, enabling Accessibility, or activating legacy Device Admin alone does not make the strong uninstall-block policy active.

No Device Owner provisioning is performed by this source build. Before attempting enrollment on a personal phone, confirm the exact Android/Samsung prerequisites and rehearse a recovery route. Device Owner policies can be difficult to remove; some recovery routes erase internal data. Do not remove accounts, provision ownership, or apply other system restrictions as part of ordinary app installation.

The uninstall switch is intentionally disabled until Device Owner is active, and its status is based on Android read-back rather than the UI switch alone.
