# Phone verification checklist — App Lock update

This source update has not been built or tested on the target phone in this workspace. Run the GitHub Actions build, install that exact artifact, and then verify on the device.

## Preserve current behavior

- Confirm existing selected-app blocking behaves exactly as before.
- Confirm the Settings screen protection and Wi-Fi/mobile/Bluetooth connectivity exceptions behave as expected on the target Samsung phone.
- Confirm no in-app button or shortcut opens Accessibility settings. With experimental Settings protection enabled, verify Accessibility pages are redirected where One UI allows; switch the guard off in Protection Companion before changing Accessibility settings. This remains best-effort, not a hard OS policy.
- Confirm theme selection still works in System, Light, and Dark modes.
- Confirm Device Owner reports Not active unless Android actually identifies this package as Device Owner.

## App PIN lock

1. Ensure Android has a secure screen lock configured.
2. Open Settings and enable **Require PIN when reopening this app**.
3. Set a 6–12 digit PIN and confirm it.
4. Navigate between Home, Settings, Diagnostics, and Connectivity: an active in-app session should not prompt on each internal screen transition.
5. Press Home, wait at least one second, and reopen Protection Companion: it should request the app PIN.
6. Enter a wrong PIN; verify the app stays locked. After five failures, verify the 30-second pause.
7. Enter the correct PIN and verify Home opens with the existing blocklist intact.
8. Confirm there is no Unlock button and no Forgot PIN/reset shortcut on the lock screen. A matching PIN should open Home as soon as its final digit is entered.
9. Verify five submitted incorrect PIN attempts trigger the 30-second pause. Verify the configured PIN length (6–12 digits) is handled without charging partial prefixes as failures while typing.
10. Verify the lock screen is excluded from screenshots/recents capture where Android honors FLAG_SECURE.
11. Test rotation, app switching, process recreation, and returning from Android Settings. Confirm the gate neither loops nor appears during ordinary in-app navigation.

## Uninstall protection

- On a normal installation, the UI must say Device Owner is Not active and uninstall protection requires Device Owner. The switch must not claim the policy is enforced.
- Do not provision Device Owner or test policy enforcement until device-specific requirements and recovery have been separately reviewed and approved.
