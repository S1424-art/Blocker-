# Manual test plan — Stage 1

## A. Source and CI provenance

- [ ] The workflow prints the repository commit SHA.
- [ ] The extracted tree contains one `settings.gradle`, the app manifest, `MainActivity.java`, `SettingsActivity.java`, `LoggerService.java`, `DevicePolicyController.java`, and `ProtectionDeviceAdminReceiver.java`.
- [ ] APK ZIP integrity passes and the DEX class list contains `MainActivity`, `SettingsActivity`, `LoggerService`, and `DevicePolicyController`.
- [ ] Version name includes the short source commit.
- [ ] No `INTERNET` permission is added.

## B. Home and app picker

- [ ] App opens to the searchable application list.
- [ ] Icons and app names match the launcher.
- [ ] Search filters by app label and package name.
- [ ] Selected apps remain selected after closing/reopening the app.
- [ ] Critical system apps and the companion itself are not selectable.
- [ ] The list has no ARM duration, lease, or Monitor navigation.

## C. Accessibility fallback

- [ ] With Accessibility off, enabling fallback does not silently claim blocking is active.
- [ ] With Accessibility on, selecting a harmless test app and enabling blocking redirects to Home after the app begins opening.
- [ ] An unselected app still opens normally.
- [ ] Turning blocking off stops the fallback.
- [ ] The app list shows one row per package even if an app declares multiple launcher activities.
- [ ] If repeated redirects trip the safety circuit breaker, the fallback shows as paused and the main switch/status stay truthful; a Device Owner suspension policy must not be silently represented as disabled.
- [ ] The UI calls this “best-effort,” not enforced suspension.
- [ ] Restarting the phone and reopening the app shows persisted preferences; service reconnection remains subject to Android behavior.

## D. Appearance and settings

- [ ] System theme follows Android appearance.
- [ ] Light theme remains light across app screens.
- [ ] Dark theme remains dark across app screens and native dialogs.
- [ ] Accessibility and Device Owner status are based on actual read-back, not only the local toggle.
- [ ] Device Owner controls are disabled when Android does not report Device Owner.

## E. Optional Settings gate — test last and with care

- [ ] Keep the setting OFF for normal use until tested.
- [ ] If deliberately tested, confirm Wi-Fi, mobile data, Internet panel, Accessibility settings, and the companion's own app info remain reachable.
- [ ] If any recovery/connectivity screen is unexpectedly redirected, disable the gate from Protection Companion immediately.
- [ ] Treat all screen-level exceptions as best-effort on Samsung One UI.

## F. Device Owner controls (not a Stage 1 phone test)

Do not perform these tests until a dedicated testOnly build and verified recovery procedure have been reviewed and approved.

- [ ] Confirm `isDeviceOwnerApp()` on the test device.
- [ ] Apply suspension to one harmless test app and check each package with Android read-back.
- [ ] Confirm any failures are reported and no critical/system app is suspended.
- [ ] Enable uninstall protection only after recovery is rehearsed; confirm with `isUninstallBlocked()`.
- [ ] Use the in-app release operation and confirm each app-level policy is actually removed.
- [ ] Verify that Device Owner enrollment itself remains and that the documented ADB recovery path is usable.
